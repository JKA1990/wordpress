<?php
/**
 * orders.php
 * Obsługa zamówień z możliwością usuwania (Delete), zmiany statusu oraz notyfikacją o nowych zamówieniach.
 */

/**
 * 1. Tworzenie / aktualizacja tabeli wp_pizzeria_orders
 */
function pizzeria_create_orders_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'pizzeria_orders';
    $charset_collate = $wpdb->get_charset_collate();

    // Dodajemy kolumny discount_amount, discount_code oraz estimated_delivery_time
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        customer_name VARCHAR(255) NOT NULL,
        customer_phone VARCHAR(50) DEFAULT '',
        customer_address TEXT NOT NULL,
        order_items LONGTEXT NOT NULL,
        discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        discount_code VARCHAR(50) DEFAULT '',
        total_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
        shipping_cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
        payment_method VARCHAR(20) NOT NULL DEFAULT 'card',
        customer_email VARCHAR(100) DEFAULT '',
        order_notes TEXT DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'Pending',
        estimated_delivery_time VARCHAR(50) DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'pizzeria_create_orders_table');

/**
 * 1b. Tworzenie / aktualizacja tabeli wp_pizzeria_order_items
 *     Używamy kolumny dish_name zamiast product_id.
 */
function pizzeria_create_order_items_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'pizzeria_order_items';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        order_id BIGINT(20) UNSIGNED NOT NULL,
        dish_name VARCHAR(255) NOT NULL,
        quantity INT(11) NOT NULL DEFAULT 1,
        price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'pizzeria_create_order_items_table');


/**
 * 2. Akcja AJAX 'save_order' – zapis zamówienia w bazie
 */
add_action('wp_ajax_save_order', 'pizzeria_save_order');
add_action('wp_ajax_nopriv_save_order', 'pizzeria_save_order');
function pizzeria_save_order() {
    global $wpdb;
    $orders_table      = $wpdb->prefix . 'pizzeria_orders';
    $order_items_table = $wpdb->prefix . 'pizzeria_order_items';

    // Minimalna walidacja – sprawdzamy, czy przesłano pole customerName
    if (empty($_POST['customerName'])) {
        wp_send_json_error(['message' => 'Brak pola customerName.']);
    }

    $customer_name  = sanitize_text_field($_POST['customerName'] ?? '');
    $customer_phone = sanitize_text_field($_POST['customerPhone'] ?? '');
    $customer_email = sanitize_email($_POST['customerEmail'] ?? '');  // Pobieramy e-mail
    
    // Pobieramy dane adresowe wysyłane z front-endu
    $delivery_address  = sanitize_text_field($_POST['delivery_address'] ?? '');
    $delivery_postcode = sanitize_text_field($_POST['delivery_postcode'] ?? '');
    
    if (!empty($delivery_address) && !empty($delivery_postcode)) {
        $customer_address = $delivery_address . ', ' . $delivery_postcode;
    } else {
        $customer_address = sanitize_text_field($_POST['customerAddress'] ?? '');
    }

    // Zbieramy dane o formie płatności
    $payment_method = sanitize_text_field($_POST['paymentMethod'] ?? 'card'); // Domyślnie karta

    // Pobieramy dodatkowe notatki z zamówienia (order-notes)
    $order_notes = sanitize_textarea_field($_POST['orderNotes'] ?? '');

    // Przetwarzamy dane koszyka
    $cart_items  = $_POST['cartItems'] ?? [];
    $cart_total = 0.0;
    foreach ($cart_items as $item) {
        $p  = floatval($item['price'] ?? 0);
        $ap = floatval($item['addonsTotalPrice'] ?? 0);
        $cart_total += ($p + $ap);
    }

    // Pobieramy koszt dostawy przesłany z front-endu
    $shipping_cost = isset($_POST['shippingCost']) ? floatval($_POST['shippingCost']) : 0.0;

    // Pobieramy wartość rabatu i kod, jeśli zostały zastosowane
    $discount_amount = isset($_POST['discountAmount']) ? floatval($_POST['discountAmount']) : 0.0;
    $discount_code   = sanitize_text_field($_POST['discountCode'] ?? '');

    // Obliczamy finalną kwotę: suma produktów + dostawa
    $final_total = $cart_total + $shipping_cost;
    // Finalna kwota po rabacie = final_total - discount_amount
    $final_total_after_discount = $final_total - $discount_amount;

    // Wstawiamy główne zamówienie – status początkowy pozostaje 'Pending'
    $wpdb->insert($orders_table, [
        'customer_name'    => $customer_name,
        'customer_phone'   => $customer_phone,
        'customer_address' => $customer_address,
        'order_items'      => wp_json_encode($cart_items),
        'discount_amount'  => $discount_amount,
        'discount_code'    => $discount_code,
        'total_price'      => $final_total_after_discount,
        'shipping_cost'    => $shipping_cost,
        'payment_method'   => $payment_method,
        'customer_email'   => $customer_email,
        'order_notes'      => $order_notes,
        'status'           => 'Pending',
        'created_at'       => current_time('mysql'),
    ]);

    $order_id = $wpdb->insert_id;
    if (!$order_id) {
        wp_send_json_error(['message' => 'Nie udało się zapisać zamówienia.']);
    }

    // =======================================
    //  DODATKOWY KROK: Zapis do pizzeria_order_items (kolumna dish_name)
    // =======================================
    foreach ($cart_items as $item) {
        // Nazwa potrawy -> dish_name
        $dish_name = sanitize_text_field($item['name'] ?? 'Unknown Dish');
        // Cena potrawy + cena dodatków
        $line_price = floatval($item['price'] ?? 0) + floatval($item['addonsTotalPrice'] ?? 0);
        // Brak quantity w JS, więc domyślna 1
        $quantity = 1;

        $wpdb->insert($order_items_table, [
            'order_id'   => $order_id,
            'dish_name'  => $dish_name,
            'quantity'   => $quantity,
            'price'      => $line_price,
            'created_at' => current_time('mysql'),
        ]);
    }

    // Przygotowujemy treść e-maila z potwierdzeniem zamówienia
    $subject = "Potwierdzenie zamówienia - #$order_id";
    $message = "Zamówienie #$order_id - Potwierdzenie zamówienia\n\n";
    $message .= "---------------------------------------\n\n";
    $message .= "Imię i nazwisko: $customer_name\n";
    $message .= "Numer telefonu: $customer_phone\n";
    $message .= "Metoda dostawy: " . ($delivery_address ? 'Dostawa' : 'Odbiór osobisty') . "\n";
    $message .= "Metoda płatności: $payment_method\n";
    $message .= "Suma produktów: " . number_format($cart_total, 2) . " zł\n";
    $message .= "Koszt dostawy: " . number_format($shipping_cost, 2) . " zł\n";
    if ($discount_amount > 0) {
        $message .= "Kwota rabatu (" . $discount_code . "): -" . number_format($discount_amount, 2) . " zł\n";
        $message .= "Łączna kwota po rabacie: " . number_format($final_total_after_discount, 2) . " zł\n\n";
    } else {
        $message .= "Łączna kwota: " . number_format($final_total, 2) . " zł\n\n";
    }

    // Dodajemy listę zamówionych produktów
    $message .= "Zamówione produkty:\n";
    if (!empty($cart_items) && is_array($cart_items)) {
        foreach ($cart_items as $item) {
            $message .= $item['name'];
            if (!empty($item['size'])) {
                $message .= " (Rozmiar: " . $item['size'] . ")";
            }
            $message .= " - " . number_format($item['price'], 2) . " zł";
            if (!empty($item['addons']) && is_array($item['addons'])) {
                $addons_text = [];
                foreach ($item['addons'] as $addon) {
                    $addons_text[] = $addon['title'] . " (+" . number_format(floatval($addon['price']), 2) . " zł)";
                }
                $message .= " [Dodatki: " . implode(", ", $addons_text) . "]";
            }
            $message .= "\n";
        }
    } else {
        $message .= "Brak produktów\n";
    }
    $message .= "\n";

    if ($delivery_address) {
        $message .= "Adres dostawy: $delivery_address\n";
        $message .= "Kod pocztowy: $delivery_postcode\n";
    }

    if (!empty($order_notes)) {
        $message .= "\nNotatki do zamówienia:\n$order_notes\n";
    }

    $message .= "\nDziękujemy za złożenie zamówienia!\n";

    $headers = array('Content-Type: text/plain; charset=UTF-8');

    // Wysyłamy e-mail do klienta
    wp_mail($customer_email, $subject, $message, $headers);

    wp_send_json_success([
        'message'  => 'Zamówienie zostało zapisane.',
        'order_id' => $order_id,
    ]);
}

/**
 * 3. Router do wyświetlania zamówień w panelu
 */
function pizzeria_render_orders_page() {
    if (isset($_GET['view']) && $_GET['view'] === 'details') {
        $order_id = intval($_GET['order_id'] ?? 0);
        pizzeria_render_order_details($order_id);
    } else {
        pizzeria_render_orders_list();
    }
}

/**
 * 4. Widok główny – lista zamówień (z usuwaniem i zmianą statusu)
 */
function pizzeria_render_orders_list() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pizzeria_orders';

    // Obsługa "Mark In Preparation"
    if (isset($_POST['mark_in_preparation'])) {
        $order_id = intval($_POST['order_id']);
        $wpdb->update($table_name, ['status' => 'W trakcie przygotowania'], ['id' => $order_id]);
        echo '<div class="notice notice-success"><p>Order #' . $order_id . ' marked as W trakcie przygotowania.</p></div>';
    }

    // Obsługa "Mark Completed"
    if (isset($_POST['mark_completed'])) {
        $order_id = intval($_POST['order_id']);
        $wpdb->update($table_name, ['status' => 'Completed'], ['id' => $order_id]);
        echo '<div class="notice notice-success"><p>Order #' . $order_id . ' marked as Completed.</p></div>';
    }

    // Obsługa "Delete" (usunięcie zamówienia)
    if (isset($_POST['delete_order'])) {
        $order_id = intval($_POST['order_id']);
        $wpdb->delete($table_name, ['id' => $order_id]);
        echo '<div class="notice notice-warning"><p>Order #' . $order_id . ' został usunięty.</p></div>';
    }

    // Pobieramy zamówienia
    $orders = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

    echo '<div class="wrap">';
    echo '<h1>Orders Management</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>
            <th>ID</th>
            <th>Customer Name</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Email</th>
            <th>Payment Method</th>
            <th>Order Items</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Actions</th>
          </tr></thead><tbody>';

    if (!$orders) {
        echo '<tr><td colspan="10">No orders found.</td></tr>';
    } else {
        foreach ($orders as $order) {
            $status = trim($order->status);
            $decoded = json_decode($order->order_items, true);
            $items_count = is_array($decoded) && !empty($decoded) ? count($decoded) . ' item(s)' : 'No items';

            echo '<tr>';
                echo '<td>' . esc_html($order->id) . '</td>';
                echo '<td>' . esc_html($order->customer_name) . '</td>';
                echo '<td>' . esc_html($order->customer_phone) . '</td>';
                echo '<td>' . esc_html($order->customer_address) . '</td>';
                echo '<td>' . esc_html($order->customer_email) . '</td>';
                echo '<td>' . esc_html($order->payment_method) . '</td>';
                echo '<td>' . esc_html($items_count) . '</td>';
                echo '<td>' . number_format(floatval($order->total_price), 2) . ' zł</td>';
                echo '<td>' . esc_html($status) . '</td>';
                echo '<td>';
                    if ($status === 'Pending') {
                        echo '<form method="post" style="display:inline;">
                                <input type="hidden" name="order_id" value="' . esc_attr($order->id) . '">
                                <button type="submit" name="mark_in_preparation" class="button button-secondary">Mark In Preparation</button>
                              </form> ';
                        echo '<form method="post" style="display:inline;">
                                <input type="hidden" name="order_id" value="' . esc_attr($order->id) . '">
                                <button type="submit" name="mark_completed" class="button button-primary">Mark Completed</button>
                              </form> ';
                    } elseif ($status === 'W trakcie przygotowania') {
                        // W przypadku statusu "W trakcie przygotowania" wyświetlamy przycisk "Mark Completed"
                        echo '<form method="post" style="display:inline;">
                                <input type="hidden" name="order_id" value="' . esc_attr($order->id) . '">
                                <button type="submit" name="mark_completed" class="button button-primary">Mark Completed</button>
                              </form> ';
                    }
                    $details_url = admin_url('admin.php?page=pizzeria-orders&view=details&order_id=' . intval($order->id));
                    echo '<a href="' . esc_url($details_url) . '" class="button">Szczegóły</a> ';
                    echo '<form method="post" style="display:inline;" onsubmit="return confirm(\'Czy na pewno usunąć zamówienie #' . $order->id . '?\');">
                            <input type="hidden" name="order_id" value="' . esc_attr($order->id) . '">
                            <button type="submit" name="delete_order" class="button button-danger">Delete</button>
                          </form>';
                echo '</td>';
            echo '</tr>';
        }
    }

    echo '</tbody></table>';
    echo '</div>';
    ?>
    <style>
        .new-order-highlight {
            background-color: #fffae6 !important;
        }
    </style>
    <script>
    jQuery(document).ready(function($) {
        function checkNewOrders() {
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'pizzeria_check_new_orders'
                },
                success: function(response) {
                    if (response.success) {
                        var newOrders = response.data.new_order_ids;
                        if (newOrders.length > 0) {
                            newOrders.forEach(function(id) {
                                var row = $('table.wp-list-table tbody tr').filter(function() {
                                    return $(this).find('td').first().text().trim() == id;
                                });
                                row.addClass('new-order-highlight');
                            });
                            if ($('#newOrderSound').length === 0) {
                                var audioHtml = '<audio id="newOrderSound" loop muted style="display:none;">' +
                                                '<source src="<?php echo plugins_url("../assets/sounds/bell.mp3", __FILE__); ?>" type="audio/mpeg">' +
                                                '</audio>';
                                $('body').append(audioHtml);
                                var audioElement = document.getElementById('newOrderSound');
                                audioElement.play().then(function() {
                                    audioElement.muted = false;
                                    console.log("Audio playback started.");
                                }).catch(function(error) {
                                    console.log("Audio playback failed:", error);
                                });
                            }
                        } else {
                            $('tr.new-order-highlight').removeClass('new-order-highlight');
                            $('#newOrderSound').remove();
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.log("Error in checkNewOrders:", status, error);
                }
            });
        }
        setInterval(checkNewOrders, 160);
    });
    </script>
    <?php
}

/**
 * 5. Widok szczegółowy jednego zamówienia – z wyświetleniem rabatu, przeliczeniem sum
 *    oraz możliwością uzupełnienia orientacyjnego czasu dostawy i wysłania e-maila.
 */
function pizzeria_render_order_details($order_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pizzeria_orders';

    $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $order_id));
    if (!$order) {
        echo '<div class="wrap"><h1>Error</h1><p>No order found for ID ' . $order_id . '</p></div>';
        return;
    }

    // Obsługa aktualizacji orientacyjnego czasu dostawy
    if(isset($_POST['update_delivery_time'])) {
        $estimated_delivery_time = sanitize_text_field($_POST['estimated_delivery_time']);
        $wpdb->update($table_name, ['estimated_delivery_time' => $estimated_delivery_time], ['id' => $order_id]);
        echo '<div class="notice notice-success"><p>Orientacyjny czas dostawy został zaktualizowany.</p></div>';
        // Możemy zaktualizować obiekt $order, aby od razu widzieć zmiany
        $order->estimated_delivery_time = $estimated_delivery_time;
    }

    // Wyliczamy sumę produktów. 
    // Suma produktów = total_price + discount_amount - shipping_cost
    $discount_amount = floatval($order->discount_amount);
    $shipping_cost   = floatval($order->shipping_cost);
    $final_price     = floatval($order->total_price);
    $cart_total      = $final_price + $discount_amount - $shipping_cost;

    echo '<div class="wrap">';
    echo '<h1>Szczegóły Zamówienia #' . intval($order->id) . '</h1>';
    echo '<p><strong>Klient:</strong> ' . esc_html($order->customer_name) . '</p>';
    echo '<p><strong>Telefon:</strong> ' . esc_html($order->customer_phone) . '</p>';
    echo '<p><strong>Email:</strong> ' . esc_html($order->customer_email) . '</p>';
    echo '<p><strong>Adres:</strong> ' . esc_html($order->customer_address) . '</p>';
    echo '<p><strong>Metoda Płatności:</strong> ' . esc_html($order->payment_method) . '</p>';
    echo '<p><strong>Suma produktów:</strong> ' . number_format($cart_total, 2) . ' zł</p>';
    if ($discount_amount > 0) {
        echo '<p><strong>Kwota rabatu (' . esc_html($order->discount_code) . '):</strong> -' . number_format($discount_amount, 2) . ' zł</p>';
    }
    echo '<p><strong>Koszt Dostawy:</strong> ' . number_format($shipping_cost, 2) . ' zł</p>';
    echo '<p><strong>Cena Razem (po rabacie):</strong> ' . number_format($final_price, 2) . ' zł</p>';
    echo '<p><strong>Status:</strong> ' . esc_html($order->status) . '</p>';
    echo '<p><strong>Utworzono dnia:</strong> ' . esc_html($order->created_at) . '</p>';
    
    if (!empty($order->order_notes)) {
        echo '<p><strong>Uwagi do zamówienia:</strong><br>' . nl2br(esc_html($order->order_notes)) . '</p>';
    }

    $cart_items = json_decode($order->order_items, true);

    echo '<hr><h2>Zamówione Produkty</h2>';
    if (empty($cart_items) || !is_array($cart_items)) {
        echo '<p>Brak produktów w zamówieniu.</p>';
    } else {
        echo '<table class="widefat striped">';
        echo '<thead><tr>
                <th>Produkt ID</th>
                <th>Nazwa</th>
                <th>Rozmiar</th>
                <th>Dodatki</th>
                <th>Cena</th>
                <th>Cena dodatków</th>
                <th>Suma</th>
              </tr></thead><tbody>';
        foreach ($cart_items as $item) {
            $product_id = intval($item['productId'] ?? 0);
            $name       = $item['name'] ?? 'Produkt';
            $size       = $item['size'] ?? '';
            $price      = floatval($item['price'] ?? 0);
            $addonsP    = floatval($item['addonsTotalPrice'] ?? 0);
            $sum        = $price + $addonsP;

            $addons = $item['addons'] ?? [];
            $addons_txt = [];
            foreach ($addons as $ad) {
                $addons_txt[] = $ad['title'] . ' (+' . number_format(floatval($ad['price']), 2) . ' zł)';
            }
            $addons_str = implode(', ', $addons_txt);

            echo '<tr>';
                echo '<td>' . $product_id . '</td>';
                echo '<td>' . esc_html($name) . '</td>';
                echo '<td>' . esc_html($size) . '</td>';
                echo '<td>' . esc_html($addons_str) . '</td>';
                echo '<td>' . number_format($price, 2) . ' zł</td>';
                echo '<td>' . number_format($addonsP, 2) . ' zł</td>';
                echo '<td>' . number_format($sum, 2) . ' zł</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    // Formularz do uzupełnienia orientacyjnego czasu dostawy
    echo '<hr><h2>Orientacyjny Czas Dostawy</h2>';
    echo '<form method="post">';
    echo '<label for="estimated_delivery_time">Orientacyjny czas dostawy:</label> ';
    echo '<input type="text" name="estimated_delivery_time" id="estimated_delivery_time" value="' . esc_attr($order->estimated_delivery_time) . '" placeholder="Np. 20:15 lub 45 minut" />';
    echo '<button type="submit" name="update_delivery_time" class="button">Zapisz czas dostawy</button>';
    echo '</form>';

    // Przycisk do wysłania e-maila
    echo '<br><button id="send_email_button" class="button button-secondary">Wyślij Email z czasem dostawy</button>';
    echo '<div id="email_response"></div>';

    echo '</div>';
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#send_email_button').on('click', function(e) {
            e.preventDefault();
            var orderId = <?php echo intval($order->id); ?>;
            var estimatedDeliveryTime = $('#estimated_delivery_time').val();
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'pizzeria_send_delivery_email',
                    order_id: orderId,
                    estimated_delivery_time: estimatedDeliveryTime
                },
                success: function(response) {
                    if(response.success) {
                        $('#email_response').html('<p style="color:green;">' + response.data.message + '</p>');
                    } else {
                        $('#email_response').html('<p style="color:red;">' + response.data.message + '</p>');
                    }
                },
                error: function(xhr, status, error) {
                    $('#email_response').html('<p style="color:red;">Wystąpił błąd przy wysyłaniu e-mail.</p>');
                }
            });
        });
    });
    </script>
    <?php
}

/**
 * 6. AJAX Handler do sprawdzania nowych zamówień
 */
add_action('wp_ajax_pizzeria_check_new_orders', 'pizzeria_check_new_orders');
add_action('wp_ajax_nopriv_pizzeria_check_new_orders', 'pizzeria_check_new_orders');
function pizzeria_check_new_orders() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pizzeria_orders';
    $latest_order_id = $wpdb->get_var("SELECT id FROM $table_name ORDER BY created_at DESC LIMIT 1");
    if ($latest_order_id) {
        wp_send_json_success(['new_order_ids' => [$latest_order_id]]);
    } else {
        wp_send_json_success(['new_order_ids' => []]);
    }
}

/**
 * 7. AJAX Handler do wysłania e-maila z informacją o orientacyjnym czasie dostawy
 */
add_action('wp_ajax_pizzeria_send_delivery_email', 'pizzeria_send_delivery_email');
add_action('wp_ajax_nopriv_pizzeria_send_delivery_email', 'pizzeria_send_delivery_email');
function pizzeria_send_delivery_email() {
    global $wpdb;
    if(!isset($_POST['order_id']) || !isset($_POST['estimated_delivery_time'])) {
        wp_send_json_error(['message' => 'Brak wymaganych parametrów.']);
    }
    $order_id = intval($_POST['order_id']);
    $estimated_delivery_time = sanitize_text_field($_POST['estimated_delivery_time']);
    $table_name = $wpdb->prefix . 'pizzeria_orders';
    $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $order_id));
    if(!$order) {
        wp_send_json_error(['message' => 'Zamówienie nie zostało znalezione.']);
    }
    // Wysyłamy e-mail do klienta z informacją o orientacyjnym czasie dostawy
    $to = $order->customer_email;
    $subject = "Orientacyjny czas dostawy - Zamówienie #" . $order->id;
    $message = "Szanowny Kliencie,\n\nOrientacyjny czas dostawy Twojego zamówienia wynosi: " . $estimated_delivery_time . ".\n\nDziękujemy za złożenie zamówienia.";
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    
    $mail_sent = wp_mail($to, $subject, $message, $headers);
    if($mail_sent) {
        wp_send_json_success(['message' => 'E-mail został wysłany do klienta.']);
    } else {
        wp_send_json_error(['message' => 'Wysyłanie e-maila nie powiodło się.']);
    }
}
