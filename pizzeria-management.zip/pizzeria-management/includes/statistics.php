<?php
/**
 * statistics.php
 * Podstrona "Statistics" w panelu WP, z możliwością filtrowania,
 * resetowania statystyk, wyświetlania sprzedaży w ujęciu dziennym,
 * TOP 3 produktów (po dish_name) oraz zapisywania "bestsellera" do opcji WP.
 */

/**
 * Rejestracja podstrony w menu "pizzeria-management"
 */
function register_statistics_page() {
    add_submenu_page(
        'pizzeria-management', // Slug menu nadrzędnego
        'Statistics',          // Tytuł strony
        'Statistics',          // Nazwa w menu
        'manage_options',      // Uprawnienia
        'pizzeria-statistics', // Slug podstrony
        'render_statistics_page' // Funkcja wyświetlająca
    );
}
add_action('admin_menu', 'register_statistics_page');

/**
 * Funkcja wyświetlająca stronę statystyk
 */
function render_statistics_page() {
    global $wpdb;

    // Nazwy tabel
    $orders_table      = $wpdb->prefix . 'pizzeria_orders';
    $order_items_table = $wpdb->prefix . 'pizzeria_order_items';

    // Obsługa resetowania statystyk (po kliknięciu w przycisk)
    if ( isset($_POST['reset_stats']) && check_admin_referer('reset_stats_action', 'reset_stats_nonce') ) {
        // Usuwamy rekordy w odpowiedniej kolejności (tabela podrzędna -> nadrzędna)
        // + reset AUTO_INCREMENT w obu tabelach
        $wpdb->query("DELETE FROM $order_items_table");
        $wpdb->query("ALTER TABLE $order_items_table AUTO_INCREMENT = 1");
        $wpdb->query("DELETE FROM $orders_table");
        $wpdb->query("ALTER TABLE $orders_table AUTO_INCREMENT = 1");

        echo '<div class="notice notice-success"><p>Statystyki zostały zresetowane (dane w tabelach usunięte).</p></div>';

        // Warto też wyczyścić zapisaną opcję bestsellera
        update_option('pizzeria_bestseller', '');
    }

    // Ile dni (domyślnie 7)
    $days = isset($_GET['days']) ? absint($_GET['days']) : 7;
    if ($days < 1) {
        $days = 7; // minimalnie 1 dzień
    }

    // Obliczamy przedział czasowy (ostatnie X dni)
    $start_date = date('Y-m-d 00:00:00', strtotime("-$days days"));
    $end_date   = date('Y-m-d 23:59:59'); // do teraz

    // Liczba zamówień z tego okresu
    $total_orders = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) 
        FROM $orders_table
        WHERE created_at BETWEEN %s AND %s
    ", $start_date, $end_date));

    // Łączna wartość zamówień (SUM(total_price)) z tego okresu
    $total_revenue = $wpdb->get_var($wpdb->prepare("
        SELECT SUM(total_price)
        FROM $orders_table
        WHERE created_at BETWEEN %s AND %s
    ", $start_date, $end_date));
    if (!$total_revenue) {
        $total_revenue = 0.0;
    }

    /**
     * TOP 3 najczęściej zamawiane produkty (po dish_name) w tym okresie
     */
    $top_products = $wpdb->get_results($wpdb->prepare("
        SELECT oi.dish_name, COUNT(*) AS order_count
        FROM $order_items_table oi
        JOIN $orders_table o ON oi.order_id = o.id
        WHERE o.created_at BETWEEN %s AND %s
        GROUP BY oi.dish_name
        ORDER BY order_count DESC
        LIMIT 3
    ", $start_date, $end_date));

    // Bestseller = pierwszy (o ile istnieje)
    $bestseller_dish_name = '';
    if (!empty($top_products)) {
        $bestseller_dish_name = $top_products[0]->dish_name; 
    }

    // Zapisujemy do opcji WP - aby front mógł sobie to pobrać i wyświetlić nakładkę
    // (np. zapisujemy samo dish_name)
    update_option('pizzeria_bestseller', $bestseller_dish_name);

    /**
     * Sprzedaż per dzień (liczba zamówień i łączna kwota)
     */
    $sales_per_day = $wpdb->get_results($wpdb->prepare("
        SELECT DATE(created_at) AS sale_date,
               COUNT(id)         AS orders_count,
               SUM(total_price)  AS daily_revenue
        FROM $orders_table
        WHERE created_at BETWEEN %s AND %s
        GROUP BY DATE(created_at)
        ORDER BY sale_date ASC
    ", $start_date, $end_date));

    ?>
    <div class="wrap">
        <h1>Order Statistics</h1>

        <!-- Prosty filtr, linki do ?days=7,14,30 -->
        <p>Show stats for:
            <a href="?page=pizzeria-statistics&days=7">Last 7 days</a> |
            <a href="?page=pizzeria-statistics&days=14">Last 14 days</a> |
            <a href="?page=pizzeria-statistics&days=30">Last 30 days</a>
        </p>
        <hr>

        <!-- Sekcja resetowania statystyk -->
        <form method="post" style="margin-bottom: 20px;">
            <?php wp_nonce_field('reset_stats_action', 'reset_stats_nonce'); ?>
            <input type="hidden" name="reset_stats" value="1"/>
            <button type="submit" class="button button-danger" 
                    onclick="return confirm('Na pewno chcesz usunąć wszystkie dane statystyk? Tej operacji nie można cofnąć.')">
                Resetuj statystyki
            </button>
        </form>

        <hr>

        <div style="margin-bottom: 20px;">
            <h2>Total Orders (last <?php echo $days; ?> days)</h2>
            <p><?php echo intval($total_orders); ?> orders</p>
        </div>

        <div style="margin-bottom: 20px;">
            <h2>Total Revenue (last <?php echo $days; ?> days)</h2>
            <p><?php echo number_format(floatval($total_revenue), 2, ',', ''); ?> zł</p>
        </div>

        <!-- TOP 3 produkty (po dish_name) -->
        <div style="margin-bottom: 20px;">
            <h2>Top 3 Dishes (last <?php echo $days; ?> days)</h2>
            <?php if (!empty($top_products)): ?>
                <ol>
                    <?php foreach ($top_products as $index => $prod): ?>
                        <?php
                            // pobieramy nazwę potrawy
                            $d_name     = $prod->dish_name;
                            $orderCount = intval($prod->order_count);
                        ?>
                        <li>
                            <strong><?php echo esc_html($d_name); ?></strong> 
                            &ndash; <?php echo $orderCount; ?> orders
                            <?php if ($index === 0): ?>
                                <!-- bestseller (pierwszy) -->
                                <span style="color: red; font-weight: bold;">(Bestseller)</span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ol>
            <?php else: ?>
                <p>No data in this period.</p>
            <?php endif; ?>
        </div>

        <hr>

        <!-- Sprzedaż per dzień -->
        <div style="margin-bottom: 20px;">
            <h2>Sales per day (last <?php echo $days; ?> days)</h2>
            <?php if (!empty($sales_per_day)): ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Orders</th>
                            <th>Daily Revenue (zł)</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($sales_per_day as $row): 
                        $date_formatted = date('Y-m-d', strtotime($row->sale_date));
                        $orders_count   = intval($row->orders_count);
                        $daily_revenue  = floatval($row->daily_revenue);
                        ?>
                        <tr>
                            <td><?php echo esc_html($date_formatted); ?></td>
                            <td><?php echo esc_html($orders_count); ?></td>
                            <td><?php echo esc_html(number_format($daily_revenue, 2, ',', '')); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No data for the selected period.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

/**
 * Funkcja tworząca tabelę `pizzeria_order_items` (przykład, jeśli jej nie masz)
 *
 * UWAGA: Tutaj możesz trzymać dish_name, a nie product_id
 */
function create_order_items_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'pizzeria_order_items';

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        order_id BIGINT(20) UNSIGNED NOT NULL,
        dish_name VARCHAR(255) NOT NULL,
        quantity INT(11) NOT NULL DEFAULT 1,
        price DECIMAL(10, 2) NOT NULL,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    if ($wpdb->last_error) {
        error_log("Error creating table: " . $wpdb->last_error);
    }
}

// Rejestracja tabeli `pizzeria_order_items` przy aktywacji wtyczki (jeśli tego potrzebujesz)
register_activation_hook(__FILE__, 'create_order_items_table');
