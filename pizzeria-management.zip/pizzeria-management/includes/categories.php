<?php
function pizzeria_register_categories_taxonomy() {
    register_taxonomy('dish_category', 'dish', [
        'labels' => ['name' => 'Categories', 'singular_name' => 'Category'],
        'hierarchical' => true,
        'show_ui' => true,
    ]);
}
add_action('init', 'pizzeria_register_categories_taxonomy');

function pizzeria_render_categories_page() {
    echo '<h1>Categories Management</h1>';
}
