<?php
if (!defined('ABSPATH')) {
    exit; // Bezpośredni dostęp zabroniony
}

/**
 * Shortcode: [pizza_menu category="..."]
 */
function cpc_pizza_menu_shortcode($atts) {
    $atts = shortcode_atts([
        'category' => '',
    ], $atts);

    // Podstawowe parametry
    $args = [
        'post_type'      => 'dish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    // Filtr kategorii
    if (!empty($atts['category'])) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'dish_category',
                'field'    => 'slug',
                'terms'    => $atts['category'],
                'operator' => 'IN',
            ]
        ];
    }

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        wp_reset_postdata();
        return '<p>Brak dań w wybranej kategorii: ' . esc_html($atts['category']) . '</p>';
    }

    // Pobieramy globalne dodatki
    $global_addons = get_posts([
        'post_type'   => 'addon',
        'post_status' => 'publish',
        'numberposts' => -1,
    ]);

    // Tablica z globalnymi dodatkami: [{"title":"Salami","price":"2"}, ...]
    $global_addons_list = [];
    if ($global_addons) {
        foreach ($global_addons as $addon_post) {
            $addon_price = get_post_meta($addon_post->ID, '_addon_price', true);
            $global_addons_list[] = [
                'title' => $addon_post->post_title,
                'price' => $addon_price,
            ];
        }
    }

    // Konwertujemy na JSON (lista globalnych dodatków)
    $global_addons_json = wp_json_encode($global_addons_list);

    ob_start();
    echo '<div class="pizza-menu-container">';

    while ($query->have_posts()) {
        $query->the_post();
        $id    = get_the_ID();
        $title = get_the_title($id);

        // Sprawdzamy, czy potrawa to 'pizza'
        $terms = get_the_terms($id, 'dish_category');
        $is_pizza = false;
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                if (strpos(strtolower($term->slug), 'pizza') !== false) {
                    $is_pizza = true;
                    break;
                }
            }
        }

        // Miniatura
        $thumb_url = get_the_post_thumbnail_url($id, 'medium');
        if (!$thumb_url) {
            $thumb_url = 'https://via.placeholder.com/150';
        }

        echo '<div class="pizza-menu-item">';
            echo '<div class="thumbnail">';
                echo '<img src="' . esc_url($thumb_url) . '" alt="' . esc_attr($title) . '">';
            echo '</div>';

            echo '<h4>' . esc_html($title) . '</h4>';

            if ($is_pizza) {
                // Pobieramy rozmiary i ceny
                $size_prices = get_post_meta($id, '_dish_size_prices', true);
                if (!is_array($size_prices)) {
                    $size_prices = [];
                }
                $size_prices_json = wp_json_encode($size_prices);

                // Pobieramy dodatki przypisane do dania
                $dish_addons = get_post_meta($id, '_dish_addons', true);
                if (!is_array($dish_addons)) {
                    $dish_addons = [];
                }

                // Łączymy globalne + dodatki dania
                $old_addons_list = [];
                foreach ($dish_addons as $old) {
                    $old_addons_list[] = [
                        'title' => $old,
                        'price' => '2.00', // Możesz dostosować cenę
                    ];
                }

                // Mergujemy dwie tablice
                $merged_addons = array_merge($global_addons_list, $old_addons_list);

                // Konwertujemy na JSON
                $addons_json = wp_json_encode($merged_addons);

                // Wyświetlamy cenę
                $display_price = 'Cena w popupie';
                if (!empty($size_prices['32cm'])) {
                    $display_price = 'od ' . number_format(floatval($size_prices['32cm']), 2, ',', '') . ' zł';
                }
                echo '<p class="price">' . esc_html($display_price) . '</p>';

                // Przycisk z isPizza=1
                echo '<button class="add-to-cart"
                    data-product-id="' . esc_attr($id) . '"
                    data-is-pizza="1"
                    data-size-prices=\'' . esc_attr($size_prices_json) . '\'
                    data-addons=\'' . esc_attr($addons_json) . '\'
                >Zamów</button>';

            } else {
                // Danie nie-pizza
                $normal_price = get_post_meta($id, '_dish_price', true);
                if (!empty($normal_price)) {
                    $normal_price = number_format(floatval($normal_price), 2, ',', '') . ' zł';
                } else {
                    $normal_price = 'Cena niedostępna';
                }
                echo '<p class="price">' . esc_html($normal_price) . '</p>';

                echo '<button class="add-to-cart"
                    data-product-id="' . esc_attr($id) . '"
                    data-is-pizza="0"
                    data-size-prices="{}"
                    data-addons="[]"
                >Zamów</button>';
            }

        echo '</div>'; // .pizza-menu-item
    }

    echo '</div>';
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('pizza_menu', 'cpc_pizza_menu_shortcode');
