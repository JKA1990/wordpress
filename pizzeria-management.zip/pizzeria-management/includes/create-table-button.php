<?php
// Przycisk do ręcznego tworzenia tabeli
if (isset($_POST['create_table'])) {
    create_delivery_table();
    echo '<div class="updated"><p>Table created successfully.</p></div>';
}
?>

<form method="post">
    <button type="submit" name="create_table" class="button button-primary">Create Table</button>
</form>
