<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcode: [pizza_menu category="..."]
 */
function pizza_menu_shortcode($atts) {
    global $wpdb; // potrzebne, by wyciągnąć bestseller z DB

    // Nazwy tabel - dostosuj do swoich prefiksów w razie potrzeby
    $orders_table      = $wpdb->prefix . 'pizzeria_orders';
    $order_items_table = $wpdb->prefix . 'pizzeria_order_items';

    // Zapytanie wyciągające NAJCZĘŚCIEJ zamawianą potrawę (grupujemy po dish_name)
    // dla całego okresu (bez filtra daty). Jeśli chcesz ograniczyć np. do 30 dni,
    // dodaj WHERE o.created_at > ...
    $bestseller_sql = "
        SELECT oi.dish_name, COUNT(*) AS order_count
        FROM $order_items_table oi
        JOIN $orders_table o ON oi.order_id = o.id
        GROUP BY oi.dish_name
        ORDER BY order_count DESC
        LIMIT 1
    ";

    $bestseller_row = $wpdb->get_row($bestseller_sql);
    // Zapisujemy nazwę najpopularniejszej potrawy do zmiennej
    $bestseller_name = $bestseller_row ? $bestseller_row->dish_name : '';

    // Przetwarzamy shortcode [pizza_menu category="..."]
    $atts = shortcode_atts([
        'category' => '',
    ], $atts);

    // Podstawowe parametry WP_Query
    $args = [
        'post_type'      => 'dish',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];

    // Jeśli podano "category", filtrujemy taksonomię dish_category
    if (!empty($atts['category'])) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'dish_category',
                'field'    => 'slug',
                'terms'    => $atts['category'],
                'operator' => 'IN',
            ]
        ];
    }

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        wp_reset_postdata();
        return '<p>Brak dań w wybranej kategorii: ' . esc_html($atts['category']) . '</p>';
    }

    // Pobieramy globalne dodatki (CPT 'addon')
    $global_addons = get_posts([
        'post_type'   => 'addon',
        'post_status' => 'publish',
        'numberposts' => -1,
    ]);

    // Tablica z globalnymi dodatkami
    $global_addons_list = [];
    if ($global_addons) {
        foreach ($global_addons as $addon_post) {
            $addon_price = get_post_meta($addon_post->ID, '_addon_price', true);
            $global_addons_list[] = [
                'title' => $addon_post->post_title,
                'price' => $addon_price,
            ];
        }
    }

    // Budujemy output w buforze
    ob_start();
    echo '<div class="pizza-menu-container">';

    while ($query->have_posts()) {
        $query->the_post();
        $id         = get_the_ID();
        $title      = get_the_title($id);
        $ingredients = get_post_meta($id, '_dish_ingredients', true);

        // Czy to pizza?
        $terms    = get_the_terms($id, 'dish_category');
        $is_pizza = false;
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                if (strpos(strtolower($term->slug), 'pizza') !== false) {
                    $is_pizza = true;
                    break;
                }
            }
        }

        // Miniatura
        $thumb_url = get_the_post_thumbnail_url($id, 'medium');
        if (!$thumb_url) {
            $thumb_url = 'https://via.placeholder.com/150';
        }

        // Kontener potrawy
        // position:relative – by dać miejsce nakładce "HIT" w rogu
        echo '<div class="pizza-menu-item" style="position:relative;">';

            // Jeśli nazwa potrawy == bestseller, wyświetlamy "HIT"
            if (!empty($bestseller_name) && ($title === $bestseller_name)) {
                echo '<div class="hit-badge">HIT</div>';
            }

            // Obrazek
            echo '<div class="thumbnail">';
                echo '<img src="' . esc_url($thumb_url) . '" alt="' . esc_attr($title) . '">';
            echo '</div>';

            // Nazwa dania
            echo '<h4>' . esc_html($title) . '</h4>';

            // Składniki
            if (!empty($ingredients)) {
                echo '<p class="ingredients">' . esc_html($ingredients) . '</p>';
            }

            // Logika cenowa
            if ($is_pizza) {
                // Dla pizzy
                $size_prices = get_post_meta($id, '_dish_size_prices', true);
                if (!is_array($size_prices)) {
                    $size_prices = [];
                }
                $size_prices_json = wp_json_encode($size_prices);

                // Dodatki przypisane wyłącznie do tej pizzy
                $dish_addons = get_post_meta($id, '_dish_addons', true);
                if (!is_array($dish_addons)) {
                    $dish_addons = [];
                }
                $old_addons_list = [];
                foreach ($dish_addons as $old) {
                    $old_addons_list[] = [
                        'title' => $old,
                        'price' => '2.00', 
                    ];
                }

                // Merge globalnych i lokalnych dodatków
                $merged_addons = array_merge($global_addons_list, $old_addons_list);
                $addons_json   = wp_json_encode($merged_addons);

                // Wyświetlamy np. "od 32cm"
                $display_price = 'Cena w popupie';
                if (!empty($size_prices['32cm'])) {
                    $display_price = 'od ' . number_format(floatval($size_prices['32cm']), 2, ',', '') . ' zł';
                }
                echo '<p class="price">' . esc_html($display_price) . '</p>';

                // Przycisk
                echo '<button class="add-to-cart"
                    data-product-id="' . esc_attr($id) . '"
                    data-product-name="' . esc_attr($title) . '"
                    data-product-price="0"
                    data-is-pizza="1"
                    data-size-prices="' . esc_attr($size_prices_json) . '"
                    data-addons="' . esc_attr($addons_json) . '"
                >Zamów</button>';

            } else {
                // Dla innych dań
                $meta_price = get_post_meta($id, '_dish_price', true);
                if (!empty($meta_price)) {
                    $raw_price_float = floatval(str_replace(',', '.', $meta_price));
                    $display_price   = number_format($raw_price_float, 2, ',', '') . ' zł';
                    $data_price_attr = number_format($raw_price_float, 2, '.', '');
                } else {
                    $display_price   = 'Cena niedostępna';
                    $data_price_attr = '0';
                }

                echo '<p class="price">' . esc_html($display_price) . '</p>';

                echo '<button class="add-to-cart"
                    data-product-id="' . esc_attr($id) . '"
                    data-product-name="' . esc_attr($title) . '"
                    data-product-price="' . esc_attr($data_price_attr) . '"
                    data-is-pizza="0"
                    data-size-prices="{}"
                    data-addons="[]"
                >Zamów</button>';
            }

        echo '</div>'; // .pizza-menu-item
    }

    echo '</div>'; // .pizza-menu-container

    wp_reset_postdata();

    // Zwracamy HTML
    return ob_get_clean();
}
add_shortcode('pizza_menu', 'pizza_menu_shortcode');
