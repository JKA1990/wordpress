<?php

function pizzeria_render_order_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_order'])) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'pizzeria_orders';
        $wpdb->insert($table_name, [
            'customer_name' => sanitize_text_field($_POST['customer_name']),
            'customer_phone' => sanitize_text_field($_POST['customer_phone']),
            'customer_address' => sanitize_textarea_field($_POST['customer_address']),
            'order_items' => sanitize_textarea_field($_POST['order_items']),
            'total_price' => floatval($_POST['total_price']),
            'status' => 'Pending',
        ]);
        echo '<p>Your order has been placed successfully!</p>';
    }

    ob_start();
    ?>
    <form method="post">
        <label for="customer_name">Name:</label>
        <input type="text" id="customer_name" name="customer_name" required>
        <label for="customer_phone">Phone:</label>
        <input type="text" id="customer_phone" name="customer_phone" required>
        <label for="customer_address">Address:</label>
        <textarea id="customer_address" name="customer_address" required></textarea>
        <label for="order_items">Order Items:</label>
        <textarea id="order_items" name="order_items" required></textarea>
        <label for="total_price">Total Price:</label>
        <input type="number" step="0.01" id="total_price" name="total_price" required>
        <button type="submit" name="submit_order">Place Order</button>
    </form>
    <?php
    return ob_get_clean();
}

add_shortcode('pizzeria_order_form', 'pizzeria_render_order_form');
