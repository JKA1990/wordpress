<?php
if (!defined('ABSPATH')) {
    exit; // Bezpośredni dostęp zabroniony
}

/**
 * -----------------------------------------
 * 1. Start sesji (lub inny mechanizm koszyka)
 * -----------------------------------------
 */
function cpc_start_cart_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'cpc_start_cart_session');

/**
 * Pobranie koszyka (z sesji)
 */
function cpc_get_cart() {
    return isset($_SESSION['cpc_cart']) ? $_SESSION['cpc_cart'] : [];
}

/**
 * Zapis koszyka (do sesji)
 */
function cpc_set_cart($cart) {
    $_SESSION['cpc_cart'] = $cart;
}

/**
 * Zwraca łączną liczbę przedmiotów w koszyku
 */
function cpc_get_cart_count($cart) {
    $count = 0;
    foreach ($cart as $item) {
        $count += $item['quantity'];
    }
    return $count;
}

/**
 * -----------------------------------------
 * 2. add_to_cart() - sumuje dodatki i rozmiary
 * -----------------------------------------
 */
function cpc_add_to_cart() {
    // Sprawdzenie nonce dla bezpieczeństwa
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'cpc_ajax_nonce')) {
        wp_send_json_error(['message' => 'Nieautoryzowany dostęp.']);
        wp_die();
    }

    // Parametry z POST
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $size       = isset($_POST['size']) ? sanitize_text_field($_POST['size']) : 'standard';
    $quantity   = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    // Dodatki: tablica stringów (np. ["Salami","Ananas"])
    $posted_addons = [];
    if (!empty($_POST['addons']) && is_array($_POST['addons'])) {
        $posted_addons = array_map('sanitize_text_field', $_POST['addons']);
    }

    if (!$product_id || $quantity < 1) {
        wp_send_json_error(['message' => 'Nieprawidłowe dane produktu.']);
        wp_die();
    }

    // [1] Pobieranie ceny bazowej (np. z _dish_size_prices)
    $base_price = 0;
    $size_prices = get_post_meta($product_id, '_dish_size_prices', true);
    if (is_array($size_prices) && isset($size_prices[$size])) {
        $base_price = floatval($size_prices[$size]);
    } else {
        // fallback
        $base_price = floatval(get_post_meta($product_id, '_dish_price', true));
    }

    // [2] Doliczenie cen dodatków (CPT 'addon', identyfikacja po post_title)
    $addons_total = 0;
    foreach ($posted_addons as $addon_title) {
        // Wyszukaj post typu 'addon' o tytule $addon_title
        $addon_post = get_page_by_title($addon_title, OBJECT, 'addon');
        if ($addon_post) {
            $addon_price = get_post_meta($addon_post->ID, '_addon_price', true);
            $addons_total += floatval($addon_price);
        }
    }

    // Cena jednej sztuki = cena bazowa + suma dodatków
    $unit_price = $base_price + $addons_total;

    // [3] Aktualizacja koszyka w sesji
    $cart = cpc_get_cart();
    // Klucz np. "123_standard"
    $cart_key = $product_id . '_' . $size;

    if (isset($cart[$cart_key])) {
        // Już istnieje w koszyku, zwiększ qty i scal addons
        $cart[$cart_key]['quantity'] += $quantity;
        // Scalamy listę addons
        $old_addons = $cart[$cart_key]['addons'];
        $cart[$cart_key]['addons'] = array_unique(array_merge($old_addons, $posted_addons));
    } else {
        // Nowa pozycja w koszyku
        $cart[$cart_key] = [
            'product_id' => $product_id,
            'size'       => $size,
            'quantity'   => $quantity,
            'price'      => $unit_price,    // Cena 1 szt. (z dodatkami)
            'addons'     => $posted_addons, // Zapisujemy same tytuły
        ];
    }

    cpc_set_cart($cart);

    // Zwrot JSON do JS
    wp_send_json_success([
        'message'    => 'Dodano do koszyka!',
        'cart_html'  => cpc_generate_cart_html($cart), // Dynamiczny HTML koszyka
        'cart_count' => cpc_get_cart_count($cart),
    ]);

    wp_die();
}
add_action('wp_ajax_add_to_cart', 'cpc_add_to_cart');
add_action('wp_ajax_nopriv_add_to_cart', 'cpc_add_to_cart');

/**
 * -----------------------------------------
 * 3. remove_from_cart() - usuwanie pozycji
 * -----------------------------------------
 */
function cpc_remove_from_cart() {
    // Sprawdzenie nonce dla bezpieczeństwa
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'cpc_ajax_nonce')) {
        wp_send_json_error(['message' => 'Nieautoryzowany dostęp.']);
        wp_die();
    }

    $cart_key = isset($_POST['cart_key']) ? sanitize_text_field($_POST['cart_key']) : '';
    if (!$cart_key) {
        wp_send_json_error(['message' => 'Nieprawidłowy klucz koszyka.']);
        wp_die();
    }

    $cart = cpc_get_cart();
    if (isset($cart[$cart_key])) {
        unset($cart[$cart_key]);
        cpc_set_cart($cart);
        wp_send_json_success([
            'message'   => 'Usunięto pozycję z koszyka.',
            'cart_html' => cpc_generate_cart_html($cart),
            'cart_count' => cpc_get_cart_count($cart),
        ]);
    } else {
        wp_send_json_error(['message' => 'Brak takiego elementu w koszyku.']);
    }

    wp_die();
}
add_action('wp_ajax_remove_from_cart', 'cpc_remove_from_cart');
add_action('wp_ajax_nopriv_remove_from_cart', 'cpc_remove_from_cart');
