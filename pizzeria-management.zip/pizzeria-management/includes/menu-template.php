<div class="menu-container">
    <?php
    $args = [
        'post_type' => 'dish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ];
    $dishes = new WP_Query($args);

    if ($dishes->have_posts()) :
        while ($dishes->have_posts()) : $dishes->the_post();
            // Pobranie danych o cenie, rabacie, składnikach i rozmiarach pizzy
            $size_prices = get_post_meta(get_the_ID(), '_dish_size_prices', true) ?: ['32cm' => '', '45cm' => '', '60cm' => ''];
            $price = get_post_meta(get_the_ID(), '_dish_price', true);
            $discount = get_post_meta(get_the_ID(), '_dish_discount', true);
            $ingredients = get_post_meta(get_the_ID(), '_dish_ingredients', true);
            $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');

            // Pobranie minimalnej ceny (dla 32cm, jeśli to Pizza)
            $categories = wp_get_post_terms(get_the_ID(), 'dish_category', ['fields' => 'names']);
            $is_pizza = in_array('Pizza', $categories);
            $base_price = $is_pizza && isset($size_prices['32cm']) ? floatval($size_prices['32cm']) : (is_numeric($price) ? floatval($price) : 0.0);

            // Obliczenie ceny po rabacie
            $discount = is_numeric($discount) ? floatval($discount) : 0.0;
            $final_price = $discount > 0 ? $base_price * (1 - $discount / 100) : $base_price;
            ?>
            <div class="menu-item">
                <div class="thumbnail">
                    <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php the_title(); ?>">
                </div>
                <div class="menu-header">
                    <div class="price">
                        <?php if ($is_pizza): ?>
                            <small>od </small>
                        <?php endif; ?>
                        <span><?php echo number_format($final_price, 2, ',', ''); ?></span> zł
                    </div>
                </div>
                <div class="menu-body">
                    <h3 class="dish-name"><?php the_title(); ?></h3>
                    <?php if (!empty($ingredients)): ?>
                        <p class="ingredients"><strong>Składniki:</strong> <?php echo esc_html($ingredients); ?></p>
                    <?php endif; ?>
                    <button class="order-button">Zamów</button>
                </div>
            </div>
        <?php endwhile;
    else : ?>
        <p>No dishes found.</p>
    <?php endif;
    wp_reset_postdata();
    ?>
</div>
