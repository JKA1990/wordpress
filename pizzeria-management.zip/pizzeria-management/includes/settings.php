<?php

// Funkcja rejestrująca ustawienia
function register_pizzeria_settings() {
    // Rejestracja ustawienia języka
    register_setting('pizzeria_settings_group', 'pizzeria_language');
    // Rejestracja ustawienia kolorystyki
    register_setting('pizzeria_settings_group', 'pizzeria_color_scheme');
}

// Dodanie strony ustawień do menu
function register_settings_menu() {
    add_submenu_page(
        'pizzeria-management',             // Rodzic w menu
        'Settings',                        // Tytuł strony
        'Settings',                        // Nazwa w menu
        'manage_options',                  // Uprawnienia wymagane do dostępu
        'pizzeria-settings',               // Slug strony
        'render_settings_page'             // Funkcja renderująca stronę
    );
}

// Funkcja renderująca stronę ustawień
function render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Pizzeria Settings</h1>
        <form method="post" action="options.php">
            <?php
            // Dodanie pól opcji i sekcji ustawień
            settings_fields('pizzeria_settings_group');
            do_settings_sections('pizzeria_settings_group');

            // Pobranie aktualnych wartości ustawień
            $language = get_option('pizzeria_language', 'en');
            $color_scheme = get_option('pizzeria_color_scheme', 'light');
            ?>

            <!-- Ustawienie języka -->
            <h2>Language Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="pizzeria_language">Select Language</label></th>
                    <td>
                        <select name="pizzeria_language" id="pizzeria_language">
                            <option value="en" <?php selected($language, 'en'); ?>>English</option>
                            <option value="pl" <?php selected($language, 'pl'); ?>>Polski</option>
                            <option value="de" <?php selected($language, 'de'); ?>>Deutsch</option>
                        </select>
                    </td>
                </tr>
            </table>

            <!-- Ustawienie kolorystyki -->
            <h2>Color Scheme</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="pizzeria_color_scheme">Select Color Scheme</label></th>
                    <td>
                        <select name="pizzeria_color_scheme" id="pizzeria_color_scheme">
                            <option value="light" <?php selected($color_scheme, 'light'); ?>>Light</option>
                            <option value="dark" <?php selected($color_scheme, 'dark'); ?>>Dark</option>
                            <option value="custom" <?php selected($color_scheme, 'custom'); ?>>Custom</option>
                        </select>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Rejestracja ustawień i strony w menu
add_action('admin_init', 'register_pizzeria_settings');
add_action('admin_menu', 'register_settings_menu');
