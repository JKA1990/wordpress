<?php

function pizzeria_register_admin_menu() {
    add_menu_page(
        'Pizzeria Management',
        'Pizzeria Management',
        'manage_options',
        'pizzeria-management',
        null,
        'dashicons-pizza',
        20
    );

    add_submenu_page(
        'pizzeria-management',
        'Orders',
        'Orders',
        'manage_options',
        'pizzeria-orders',
        'pizzeria_render_orders_page'
    );
}
add_action('admin_menu', 'pizzeria_register_admin_menu');
