<?php
// ------------------------------------------------------------------
// Rejestracja typu postu "Addon"
// ------------------------------------------------------------------
function pizzeria_register_addons_post_type() {
    register_post_type('addon', [
        'labels' => [
            'name'               => 'Addons',
            'singular_name'      => 'Addon',
            'add_new'            => 'Add New Addon',
            'add_new_item'       => 'Add New Addon',
            'edit_item'          => 'Edit Addon',
            'new_item'           => 'New Addon',
            'view_item'          => 'View Addon',
            'search_items'       => 'Search Addons',
            'not_found'          => 'No addons found',
            'not_found_in_trash' => 'No addons found in trash',
        ],
        'public'       => true,
        'menu_icon'    => 'dashicons-plus-alt',
        'supports'     => ['title','thumbnail'],
        'show_in_menu' => 'pizzeria-management',
        'rewrite'      => ['slug' => 'addons']
    ]);
}
add_action('init', 'pizzeria_register_addons_post_type');


// ------------------------------------------------------------------
// Dodanie metaboxu do edycji ceny dodatku (panel admin)
// ------------------------------------------------------------------
function pizzeria_add_addon_meta_boxes() {
    add_meta_box(
        'addon_details',
        'Addon Details',
        'pizzeria_render_addon_meta_box',
        'addon',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'pizzeria_add_addon_meta_boxes');

function pizzeria_render_addon_meta_box($post) {
    // Wyświetlenie ID dodatku jako pole tylko do odczytu
    ?>
    <p>
        <label>ID:</label>
        <input type="text" readonly value="<?php echo esc_attr($post->ID); ?>" class="widefat">
    </p>
    <?php
    // Pobieramy ceny dla poszczególnych rozmiarów
    $price_32 = get_post_meta($post->ID, '_addon_price_32', true);
    $price_45 = get_post_meta($post->ID, '_addon_price_45', true);
    $price_60 = get_post_meta($post->ID, '_addon_price_60', true);
    ?>
    <label for="addon_price_32">Price for 32cm:</label>
    <input type="number" step="0.01" name="addon_price_32" id="addon_price_32" value="<?php echo esc_attr($price_32); ?>" class="widefat"><br><br>
    
    <label for="addon_price_45">Price for 45cm:</label>
    <input type="number" step="0.01" name="addon_price_45" id="addon_price_45" value="<?php echo esc_attr($price_45); ?>" class="widefat"><br><br>
    
    <label for="addon_price_60">Price for 60cm:</label>
    <input type="number" step="0.01" name="addon_price_60" id="addon_price_60" value="<?php echo esc_attr($price_60); ?>" class="widefat"><br><br>
    <?php
}

// Zapis metadanych dodatku
function pizzeria_save_addon_meta_data($post_id) {
    if (isset($_POST['addon_price_32'])) {
        update_post_meta($post_id, '_addon_price_32', sanitize_text_field($_POST['addon_price_32']));
    }
    if (isset($_POST['addon_price_45'])) {
        update_post_meta($post_id, '_addon_price_45', sanitize_text_field($_POST['addon_price_45']));
    }
    if (isset($_POST['addon_price_60'])) {
        update_post_meta($post_id, '_addon_price_60', sanitize_text_field($_POST['addon_price_60']));
    }
}
add_action('save_post', 'pizzeria_save_addon_meta_data');


// ------------------------------------------------------------------
// Wyświetlanie dodatków w zamówieniach na frontendzie
// ------------------------------------------------------------------
function pizzeria_render_addons_form() {
    $addons = get_posts([
        'post_type'   => 'addon',
        'post_status' => 'publish',
        'numberposts' => -1,
    ]);

    if ($addons):
        ?>
        <h4>Choose Addons:</h4>
        <?php foreach ($addons as $addon):
            // Pobieramy ceny dla poszczególnych rozmiarów, ustawiając domyślnie 0.00, jeśli nie zostały zdefiniowane
            $price_32 = get_post_meta($addon->ID, '_addon_price_32', true);
            $price_45 = get_post_meta($addon->ID, '_addon_price_45', true);
            $price_60 = get_post_meta($addon->ID, '_addon_price_60', true);
            
            $price_32 = $price_32 ? $price_32 : '0.00';
            $price_45 = $price_45 ? $price_45 : '0.00';
            $price_60 = $price_60 ? $price_60 : '0.00';
            ?>
            <label>
                <!-- Teraz przekazujemy ID dodatku -->
                <input type="checkbox" name="addons[]" value="<?php echo esc_attr($addon->ID); ?>">
                <?php echo esc_html($addon->post_title); ?> 
                (32cm: +<?php echo esc_html($price_32); ?>, 45cm: +<?php echo esc_html($price_45); ?>, 60cm: +<?php echo esc_html($price_60); ?>)
            </label><br>
        <?php endforeach; ?>
        <?php
    endif;
}

// Zapis wybranych dodatków przy składaniu zamówienia
function pizzeria_save_order_addons($order_id) {
    if (isset($_POST['addons']) && is_array($_POST['addons'])) {
        update_post_meta($order_id, '_order_addons', array_map('sanitize_text_field', $_POST['addons']));
    }
}
add_action('save_post_pizzeria_order', 'pizzeria_save_order_addons');


// ------------------------------------------------------------------
// Dodanie kolumny z ID do listy dodatków w panelu administracyjnym
// ------------------------------------------------------------------
function pizzeria_add_addon_id_column($columns) {
    // Dodajemy kolumnę "ID" na początku (możesz zmienić kolejność według potrzeb)
    $new_columns = ['cb' => $columns['cb'], 'addon_id' => 'ID'];
    unset($columns['cb']);
    return array_merge($new_columns, $columns);
}
add_filter('manage_edit-addon_columns', 'pizzeria_add_addon_id_column');

function pizzeria_show_addon_id_column($column, $post_id) {
    if ('addon_id' === $column) {
        echo esc_html($post_id);
    }
}
add_action('manage_addon_posts_custom_column', 'pizzeria_show_addon_id_column', 10, 2);

?>
