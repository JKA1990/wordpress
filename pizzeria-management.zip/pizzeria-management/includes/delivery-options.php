<?php

// Funkcja tworząca tabelę opcji dostawy
function create_delivery_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'delivery_options';

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        city VARCHAR(255) NOT NULL,
        postal_code VARCHAR(20) NOT NULL,
        delivery_price DECIMAL(10, 2) NOT NULL,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    if ($wpdb->last_error) {
        error_log("Error creating table: " . $wpdb->last_error);
    }
}

// Dodanie opcji dostawy do menu wtyczki
function register_delivery_menu() {
    add_submenu_page(
        'pizzeria-management',
        'Delivery Options',
        'Delivery Options',
        'manage_options',
        'delivery-options',
        'render_delivery_options_page'
    );
}
add_action('admin_menu', 'register_delivery_menu');

// Funkcja renderująca stronę opcji dostawy
function render_delivery_options_page() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'delivery_options';

    // Sprawdzenie, czy tabela istnieje
    $table_check = $wpdb->get_var("SHOW TABLES LIKE '$table_name';");
    if (!$table_check) {
        echo '<div class="error"><p>Error: Table does not exist!</p></div>';
        return;
    }

    // Obsługa przesyłania pliku CSV
    if (isset($_POST['upload_csv'])) {
        if (!empty($_FILES['csv_file']['tmp_name'])) {
            $file = fopen($_FILES['csv_file']['tmp_name'], 'r');

            // Weryfikacja i przetwarzanie pliku CSV
            while (($data = fgetcsv($file, 1000, ',')) !== false) {
                $city = sanitize_text_field($data[0]);
                $postal_code = sanitize_text_field($data[1]);
                $delivery_price = floatval($data[2]);

                if (!empty($city) && !empty($postal_code) && is_numeric($delivery_price)) {
                    $wpdb->insert($table_name, [
                        'city' => $city,
                        'postal_code' => $postal_code,
                        'delivery_price' => $delivery_price,
                    ]);
                }
            }

            fclose($file);
            echo '<div class="updated"><p>CSV file imported successfully.</p></div>';
        } else {
            echo '<div class="error"><p>Please upload a valid CSV file.</p></div>';
        }
    }

    // Obsługa usuwania wpisu
    if (isset($_POST['delete_delivery_option'])) {
        $id = intval($_POST['id']);
        $wpdb->delete($table_name, ['id' => $id]);

        if ($wpdb->last_error) {
            echo '<div class="error"><p>Error: ' . esc_html($wpdb->last_error) . '</p></div>';
        } else {
            echo '<div class="updated"><p>Delivery option deleted successfully.</p></div>';
        }
    }

    // Obsługa edycji wpisu
    if (isset($_POST['edit_delivery_option'])) {
        $id = intval($_POST['id']);
        $city = sanitize_text_field($_POST['city']);
        $postal_code = sanitize_text_field($_POST['postal_code']);
        $delivery_price = floatval($_POST['delivery_price']);

        $wpdb->update($table_name, [
            'city' => $city,
            'postal_code' => $postal_code,
            'delivery_price' => $delivery_price,
        ], ['id' => $id]);

        if ($wpdb->last_error) {
            echo '<div class="error"><p>Error: ' . esc_html($wpdb->last_error) . '</p></div>';
        } else {
            echo '<div class="updated"><p>Delivery option updated successfully.</p></div>';
        }
    }

    // Pobieranie danych z tabeli
    $delivery_options = $wpdb->get_results("SELECT * FROM $table_name ORDER BY city ASC");

    ?>
    <div class="wrap">
        <h1>Delivery Options</h1>

        <!-- Formularz przesyłania pliku CSV -->
        <h2>Import Delivery Options from CSV</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit" name="upload_csv" class="button button-primary">Upload CSV</button>
        </form>

        <p><strong>CSV Format:</strong> Each row should contain <code>City, Postal Code, Delivery Price</code>.</p>

        <!-- Wyświetlenie istniejących opcji dostawy z możliwością edycji i usuwania -->
        <h2>Existing Delivery Options</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>City</th>
                    <th>Postal Code</th>
                    <th>Delivery Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($delivery_options)): ?>
                    <?php foreach ($delivery_options as $option): ?>
                        <tr>
                            <form method="post">
                                <input type="hidden" name="id" value="<?php echo esc_attr($option->id); ?>">
                                <td>
                                    <input type="text" name="city" value="<?php echo esc_attr($option->city); ?>" required>
                                </td>
                                <td>
                                    <input type="text" name="postal_code" value="<?php echo esc_attr($option->postal_code); ?>" required>
                                </td>
                                <td>
                                    <input type="number" step="0.01" name="delivery_price" value="<?php echo esc_attr($option->delivery_price); ?>" required>
                                </td>
                                <td>
                                    <button type="submit" name="edit_delivery_option" class="button button-primary">Save</button>
                                    <button type="submit" name="delete_delivery_option" class="button button-danger" onclick="return confirm('Are you sure you want to delete this delivery option?');">Delete</button>
                                </td>
                            </form>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">No delivery options found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
