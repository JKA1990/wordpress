<?php
// Dodanie strony "Manage Categories" do menu "Pizza Management"
function pizzeria_add_menu_categories_page() {
    add_submenu_page(
        'pizzeria-management',          // Rodzic w menu
        'Manage Categories',            // Tytuł strony
        'Manage Categories',            // Nazwa w menu
        'manage_options',               // Uprawnienia
        'pizzeria-manage-categories',   // Unikalny slug
        'pizzeria_render_categories_page' // Funkcja renderująca
    );
}
add_action('admin_menu', 'pizzeria_add_menu_categories_page');

// Funkcja renderująca stronę "Manage Categories"
function pizzeria_render_categories_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Obsługa dodawania nowej kategorii
    if (isset($_POST['add_category'])) {
        $new_category_name = sanitize_text_field($_POST['new_category_name']);
        if (!empty($new_category_name)) {
            $result = wp_insert_term($new_category_name, 'dish_category');
            if (!is_wp_error($result)) {
                echo '<div class="updated"><p>Category added successfully!</p></div>';
            } else {
                echo '<div class="error"><p>Error: ' . esc_html($result->get_error_message()) . '</p></div>';
            }
        }
    }

    // Obsługa usuwania kategorii
    if (isset($_POST['delete_category'])) {
        $category_id = intval($_POST['category_id']);
        $result = wp_delete_term($category_id, 'dish_category');
        if (!is_wp_error($result)) {
            echo '<div class="updated"><p>Category deleted successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Error: ' . esc_html($result->get_error_message()) . '</p></div>';
        }
    }

    // Pobranie istniejących kategorii
    $categories = get_terms([
        'taxonomy' => 'dish_category',
        'hide_empty' => false,
    ]);

    ?>
    <div class="wrap">
        <h1>Manage Categories</h1>
        <form method="post" style="margin-bottom: 20px;">
            <label for="new_category_name">Add New Category:</label>
            <input type="text" name="new_category_name" id="new_category_name" required>
            <button type="submit" name="add_category" class="button button-primary">Add Category</button>
        </form>

        <h2>Existing Categories</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($categories)) : ?>
                    <?php foreach ($categories as $category) : ?>
                        <tr>
                            <td><?php echo esc_html($category->name); ?></td>
                            <td><?php echo esc_html($category->slug); ?></td>
                            <td>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="category_id" value="<?php echo esc_attr($category->term_id); ?>">
                                    <button type="submit" name="delete_category" class="button button-secondary">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="3">No categories found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
