<?php
// Rejestracja typu postu "Dish"
function pizzeria_register_dishes_post_type() {
    register_post_type('dish', [
        'labels' => [
            'name' => 'Dishes',
            'singular_name' => 'Dish',
            'add_new' => 'Add New Dish',
            'add_new_item' => 'Add New Dish',
            'edit_item' => 'Edit Dish',
            'new_item' => 'New Dish',
            'view_item' => 'View Dish',
            'search_items' => 'Search Dishes',
            'not_found' => 'No dishes found',
            'not_found_in_trash' => 'No dishes found in trash',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-carrot',
        'supports' => ['title', 'thumbnail'],
        'show_in_menu' => true,
		'show_in_menu' => 'pizzeria-management', // Powiązanie z głównym menu wtyczki
        'has_archive' => true,
        'rewrite' => [
            'slug' => 'dishes',
            'with_front' => false,
        ],
    ]);
}
add_action('init', 'pizzeria_register_dishes_post_type');

// Rejestracja kategorii "Dish Category"
function pizzeria_register_dish_category_taxonomy() {
    register_taxonomy('dish_category', ['dish'], [
        'labels' => [
            'name' => 'Dish Categories',
            'singular_name' => 'Dish Category',
            'search_items' => 'Search Categories',
            'all_items' => 'All Categories',
            'edit_item' => 'Edit Category',
            'update_item' => 'Update Category',
            'add_new_item' => 'Add New Category',
            'new_item_name' => 'New Category Name',
            'menu_name' => 'Categories',
        ],
        'hierarchical' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'public' => true,
        'rewrite' => [
            'slug' => 'dish-category',
            'with_front' => false,
        ],
    ]);
}
add_action('init', 'pizzeria_register_dish_category_taxonomy');

// Dodanie metaboxów do edycji dań
function pizzeria_add_dish_meta_boxes() {
    add_meta_box(
        'dish_details',
        'Dish Details',
        'pizzeria_render_dish_meta_box',
        'dish',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'pizzeria_add_dish_meta_boxes');

// Renderowanie metaboxu
function pizzeria_render_dish_meta_box($post) {
    // Pobierz przypisane kategorie
    $categories = get_terms(['taxonomy' => 'dish_category', 'hide_empty' => false]);
    $assigned_categories = wp_get_object_terms($post->ID, 'dish_category', ['fields' => 'names']);

    // Sprawdź, czy danie jest przypisane do kategorii "Pizza"
    $is_pizza = in_array('Pizza', $assigned_categories);

    $price = get_post_meta($post->ID, '_dish_price', true);
    $size_prices = get_post_meta($post->ID, '_dish_size_prices', true) ?: ['32cm' => '', '45cm' => '', '60cm' => ''];
    $ingredients = get_post_meta($post->ID, '_dish_ingredients', true);

    ?>
    <p>
        <label for="dish_price">Price:</label>
        <input type="number" step="0.01" name="dish_price" id="dish_price" value="<?php echo esc_attr($price); ?>" class="widefat">
    </p>
    <p>
        <label for="dish_ingredients">Ingredients:</label>
        <textarea name="dish_ingredients" id="dish_ingredients" class="widefat"><?php echo esc_textarea($ingredients); ?></textarea>
    </p>

    <?php if ($is_pizza): ?>
        <p>
            <strong>Pizza Prices:</strong><br>
            <label for="dish_price_32">32cm:</label>
            <input type="number" step="0.01" name="dish_size_prices[32cm]" id="dish_price_32" value="<?php echo esc_attr($size_prices['32cm']); ?>" class="widefat"><br>
            <label for="dish_price_45">45cm:</label>
            <input type="number" step="0.01" name="dish_size_prices[45cm]" id="dish_price_45" value="<?php echo esc_attr($size_prices['45cm']); ?>" class="widefat"><br>
            <label for="dish_price_60">60cm:</label>
            <input type="number" step="0.01" name="dish_size_prices[60cm]" id="dish_price_60" value="<?php echo esc_attr($size_prices['60cm']); ?>" class="widefat">
        </p>
    <?php endif; ?>

    <p>
        <label for="dish_category">Category:</label>
        <select name="dish_category[]" id="dish_category" multiple="multiple" class="widefat">
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo esc_attr($category->term_id); ?>" <?php selected(in_array($category->name, $assigned_categories)); ?>>
                    <?php echo esc_html($category->name); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php
}


// Zapis metadanych i kategorii
function pizzeria_save_dish_meta_data($post_id) {
    if (get_post_type($post_id) !== 'dish') {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['dish_price'])) {
        update_post_meta($post_id, '_dish_price', sanitize_text_field($_POST['dish_price']));
    }

    if (isset($_POST['dish_ingredients'])) {
        update_post_meta($post_id, '_dish_ingredients', sanitize_textarea_field($_POST['dish_ingredients']));
    }

    if (isset($_POST['dish_size_prices']) && is_array($_POST['dish_size_prices'])) {
        $sanitized_size_prices = array_map('sanitize_text_field', $_POST['dish_size_prices']);
        update_post_meta($post_id, '_dish_size_prices', $sanitized_size_prices);
    }

    if (isset($_POST['dish_category'])) {
        $categories = array_map('intval', $_POST['dish_category']);
        wp_set_object_terms($post_id, $categories, 'dish_category');
    }
}
add_action('save_post', 'pizzeria_save_dish_meta_data');
