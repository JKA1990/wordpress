<?php
/**
 * Funkcja tworząca tabelę dla kodów rabatowych
 */
function create_discount_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'discount_codes';

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        code VARCHAR(50) NOT NULL UNIQUE,
        discount_percentage DECIMAL(5, 2) NOT NULL,
        active_from DATETIME DEFAULT NULL,
        active_to DATETIME DEFAULT NULL,
        is_used TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    if ($wpdb->last_error) {
        error_log("Error creating discount_codes table: " . $wpdb->last_error);
    }
}
register_activation_hook(__FILE__, 'create_discount_table');

/**
 * Dodanie sekcji "Discount Codes" do menu
 */
function register_discount_menu() {
    add_submenu_page(
        'pizzeria-management',
        'Discount Codes',
        'Discount Codes',
        'manage_options',
        'discount-codes',
        'render_discount_codes_page'
    );
}
add_action('admin_menu', 'register_discount_menu');

/**
 * Funkcja renderująca stronę generatora kodów rabatowych
 */
function render_discount_codes_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'discount_codes';

    // Obsługa dodawania nowego kodu rabatowego
    if (isset($_POST['save_discount_code'])) {
        // Pobieramy dane z formularza – kod, procent, datę od i datę do
        $code = strtoupper(trim($_POST['code']));
        $discount_percentage = floatval($_POST['discount_percentage']);
        $active_from = !empty($_POST['active_from']) ? sanitize_text_field($_POST['active_from']) : null;
        $active_to = !empty($_POST['active_to']) ? sanitize_text_field($_POST['active_to']) : null;

        // Jeżeli kod nie został wpisany, można dodać walidację, np. generować automatycznie lub zgłaszać błąd.
        if (empty($code)) {
            echo '<div class="error"><p>Proszę wpisać własny kod rabatowy.</p></div>';
        } else {
            $wpdb->insert($table_name, [
                'code' => $code,
                'discount_percentage' => $discount_percentage,
                'active_from' => $active_from,
                'active_to' => $active_to,
            ]);

            if ($wpdb->last_error) {
                echo '<div class="error"><p>Error: ' . esc_html($wpdb->last_error) . '</p></div>';
            } else {
                echo '<div class="updated"><p>Discount code saved successfully: <strong>' . esc_html($code) . '</strong></p></div>';
            }
        }
    }

    // Pobieranie istniejących kodów rabatowych
    $discount_codes = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

    ?>
    <div class="wrap">
        <h1>Discount Codes</h1>

        <!-- Formularz dodawania nowego kodu rabatowego -->
        <h2>Add New Discount Code</h2>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="code">Discount Code</label></th>
                    <td><input type="text" name="code" id="code" placeholder="Wpisz własny kod" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="discount_percentage">Discount Percentage</label></th>
                    <td><input type="number" step="0.01" name="discount_percentage" id="discount_percentage" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="active_from">Active From</label></th>
                    <td><input type="datetime-local" name="active_from" id="active_from"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="active_to">Active To</label></th>
                    <td><input type="datetime-local" name="active_to" id="active_to"></td>
                </tr>
            </table>
            <button type="submit" name="save_discount_code" class="button button-primary">Save Discount Code</button>
        </form>

        <!-- Wyświetlenie istniejących kodów rabatowych -->
        <h2>Existing Discount Codes</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Discount (%)</th>
                    <th>Active From</th>
                    <th>Active To</th>
                    <th>Used</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($discount_codes)): ?>
                    <?php foreach ($discount_codes as $code): ?>
                        <tr>
                            <td><?php echo esc_html($code->code); ?></td>
                            <td><?php echo esc_html($code->discount_percentage); ?></td>
                            <td><?php echo esc_html($code->active_from); ?></td>
                            <td><?php echo esc_html($code->active_to); ?></td>
                            <td><?php echo $code->is_used ? 'Yes' : 'No'; ?></td>
                            <td><?php echo esc_html($code->created_at); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6">No discount codes found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Funkcja do walidacji kodu rabatowego na froncie
 * Sprawdza, czy kod istnieje, nie jest użyty, oraz czy aktualna data mieści się między active_from a active_to (jeśli są ustawione)
 */
function validate_discount_code($code) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'discount_codes';

    $now = current_time('mysql');

    // Zapytanie sprawdzające również zakres dat
    $discount_code = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name 
         WHERE code = %s 
           AND is_used = 0 
           AND (active_from IS NULL OR active_from <= %s)
           AND (active_to IS NULL OR active_to >= %s)",
        $code, $now, $now
    ));

    if ($discount_code) {
        return $discount_code->discount_percentage;
    } else {
        return false;
    }
}

/**
 * Funkcja oznaczająca kod jako użyty
 */
function mark_discount_code_as_used($code) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'discount_codes';
    $wpdb->update($table_name, ['is_used' => 1], ['code' => $code]);
    if ($wpdb->last_error) {
        error_log("Error marking code as used: " . $wpdb->last_error);
    }
}

/**
 * Endpoint AJAX – walidacja kodu rabatowego
 */
add_action('wp_ajax_apply_discount_code', function () {
    if (!isset($_POST['code'])) {
        wp_send_json_error(['message' => 'No discount code provided.']);
    }

    $code = sanitize_text_field($_POST['code']);
    $discount = validate_discount_code($code);

    if ($discount !== false) {
        mark_discount_code_as_used($code);
        wp_send_json_success(['discount' => $discount]);
    } else {
        wp_send_json_error(['message' => 'Invalid, expired, or already used discount code.']);
    }
});
