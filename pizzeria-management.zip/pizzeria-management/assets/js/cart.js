jQuery(document).ready(function ($) {
    let cartItems = []; // Tablica z elementami koszyka

    // Funkcja wyświetlająca zawartość koszyka
    function showCartPopup() {
        let cartHtml = '';
        let totalPrice = 0;

        if (cartItems.length === 0) {
            cartHtml = '<p>Koszyk jest pusty</p>';
        } else {
            cartItems.forEach((item) => {
                let itemTotalPrice = item.price + item.addonsTotalPrice;
                totalPrice += itemTotalPrice;
                let addonsText = (item.addons && item.addons.length > 0)
                    ? item.addons.map(addon => `${addon.title} (+${addon.price.toFixed(2)} zł)`).join(', ')
                    : 'Brak';

                cartHtml += `
                    <div style="display: flex; align-items: center; margin-bottom: 10px;">
                        <img src="${item.image}" alt="Produkt" style="width: 50px; height: 50px; margin-right: 10px;">
                        <div>
                            <p><strong>${item.name}</strong></p>
                            ${item.size ? `<p>Rozmiar: ${item.size}</p>` : ""}
                            <p>Dodatki: ${addonsText}</p>
                            <p>Razem za produkt: ${itemTotalPrice.toFixed(2)} zł</p>
                        </div>
                    </div>
                    <hr>
                `;
            });
        }

        cartHtml += `
            <div style="display: flex; justify-content: space-between; margin-top: 10px;">
                <p><strong>Łączna cena: ${totalPrice.toFixed(2)} zł</strong></p>
                <button id="continue-shopping" class="swal2-styled">Kupuj dalej</button>
                <button id="finalize-order" class="swal2-styled swal2-confirm">Finalizacja zamówienia</button>
            </div>
        `;

        Swal.fire({
            title: 'Twój Koszyk',
            html: cartHtml,
            showConfirmButton: false,
            didOpen: () => {
                $('#continue-shopping').off('click').on('click', function () {
                    Swal.close();
                });
                $('#finalize-order').off('click').on('click', function () {
                    showOrderDetailsPopup();
                });
            }
        });
    }

    // Funkcja wyświetlająca dane do zamówienia
    async function showOrderDetailsPopup() {
        Swal.fire({
            title: 'Podaj dane do zamówienia',
            html: `
                <input id="customer-name" class="swal2-input" placeholder="Imię i Nazwisko">
                <input id="customer-phone" class="swal2-input" placeholder="Numer telefonu">
                <input id="customer-email" class="swal2-input" placeholder="Adres e-mail">  
                <textarea id="order-notes" class="swal2-textarea" placeholder="Uwagi do zamówienia (np. bez cebuli)"></textarea>
                <div style="text-align: left; margin-top: 10px;">
                    <label>
                        <input type="radio" name="delivery-method" value="pickup" checked>
                        Odbiór osobisty
                    </label><br>
                    <label>
                        <input type="radio" name="delivery-method" value="delivery">
                        Dostawa
                    </label>
                </div>
                <div id="delivery-fields" style="margin-top: 10px; display: none;">
                    <input id="delivery-address" class="swal2-input" placeholder="Adres dostawy">
                    <input id="delivery-postcode" class="swal2-input" placeholder="Kod pocztowy">
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Dalej',
            cancelButtonText: 'Anuluj',
            didOpen: () => {
                $('input[name="delivery-method"]').off('change').on('change', function () {
                    if (this.value === 'delivery') {
                        $('#delivery-fields').show();
                    } else {
                        $('#delivery-fields').hide();
                    }
                });
            },
            preConfirm: async () => {
                let customerName     = $('#customer-name').val().trim();
                let customerPhone    = $('#customer-phone').val().trim();
                let customerEmail    = $('#customer-email').val().trim();
                let orderNotes       = $('#order-notes').val().trim();
                let deliveryMethod   = $('input[name="delivery-method"]:checked').val();
                let deliveryAddress  = $('#delivery-address').val().trim();
                let deliveryPostcode = $('#delivery-postcode').val().trim();

                let shippingCost = 0;
                if (deliveryMethod === 'delivery') {
                    try {
                        const response = await $.ajax({
                            url: wpAjax.ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'get_delivery_cost',
                                postcode: deliveryPostcode
                            }
                        });
                        console.log('Odpowiedź z get_delivery_cost:', response);
                        if (response.success) {
                            shippingCost = parseFloat(response.data.cost);
                        } else {
                            Swal.showValidationMessage('Nie udało się pobrać kosztu dostawy!');
                            return false;
                        }
                    } catch (error) {
                        console.error('Błąd get_delivery_cost:', error);
                        Swal.showValidationMessage('Błąd podczas pobierania kosztu dostawy.');
                        return false;
                    }
                }

                if (!customerName || !customerPhone || !customerEmail) {
                    Swal.showValidationMessage('Podaj swoje dane kontaktowe!');
                    return false;
                }
                if (deliveryMethod === 'delivery' && (!deliveryAddress || !deliveryPostcode)) {
                    Swal.showValidationMessage('Podaj adres i kod pocztowy dla dostawy!');
                    return false;
                }

                return {
                    customerName,
                    phone: customerPhone,
                    email: customerEmail,
                    orderNotes,
                    deliveryMethod,
                    delivery_address: deliveryAddress,
                    delivery_postcode: deliveryPostcode,
                    shippingCost,
                    discountAmount: 0,
                    discountCode: ''
                };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                let orderData = result.value;
                showPaymentMethodPopup(orderData);
            }
        });
    }

    // Funkcja wyboru metody płatności
    function showPaymentMethodPopup(orderData) {
        Swal.fire({
            title: 'Wybierz metodę płatności',
            html: ` 
                <div style="text-align: left; margin-top: 10px;">
                    <label>
                        <input type="radio" name="payment-method" value="card" checked>
                        Karta
                    </label><br>
                    <label>
                        <input type="radio" name="payment-method" value="cash">
                        Gotówka
                    </label>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Dalej',
            cancelButtonText: 'Anuluj',
            preConfirm: () => {
                let paymentMethod = $('input[name="payment-method"]:checked').val();
                if (!paymentMethod) {
                    Swal.showValidationMessage('Wybierz metodę płatności!');
                    return false;
                }
                orderData.paymentMethod = paymentMethod;
                return orderData;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                let orderData = result.value;
                showOrderSummaryPopup(orderData);
            }
        });
    }

    // Funkcja generująca HTML podsumowania zamówienia – dynamicznie przelicza wartości
    function generateOrderHtml(orderData) {
        // Obliczamy sumę produktów (baseTotal) z koszyka
        let baseTotal = cartItems.reduce((total, item) => total + (item.price + item.addonsTotalPrice), 0);
        let discountAmount = orderData.discountAmount || 0;
        let discountCode   = orderData.discountCode || '';
        let shippingCost   = orderData.shippingCost || 0;
        let finalTotal = baseTotal + shippingCost - discountAmount;

        let html = `<div style="text-align:left;">`;
        html += `<p><strong>Podsumowanie zamówienia:</strong></p>`;
        html += `<ul>`;
        cartItems.forEach((item) => {
            let itemTotal = item.price + item.addonsTotalPrice;
            html += `<li>${item.name}${item.size ? ' (' + item.size + ')' : ''}: ${itemTotal.toFixed(2)} zł</li>`;
        });
        html += `</ul>`;
        html += `<p><strong>Suma produktów:</strong> ${baseTotal.toFixed(2)} zł</p>`;
        if (discountAmount > 0) {
            html += `<p><strong>Rabat (${discountCode}):</strong> -${discountAmount.toFixed(2)} zł</p>`;
        }
        html += `<p><strong>Koszt dostawy:</strong> ${shippingCost.toFixed(2)} zł</p>`;
        html += `<p><strong>Razem do zapłaty:</strong> ${finalTotal.toFixed(2)} zł</p>`;
        html += `<div id="discount-section" style="margin-top:10px;">`;
        html += `<input id="discount-code" class="swal2-input" placeholder="Kod rabatowy">`;
        html += `<button id="apply-discount" class="swal2-styled" style="margin-top:5px;">Zastosuj kod rabatowy</button>`;
        html += `<div id="discount-message" style="color:red; margin-top:5px;"></div>`;
        html += `</div>`;
        html += `</div>`;
        return html;
    }

    // Funkcja wyświetlająca podsumowanie zamówienia i obsługująca kod rabatowy
    function showOrderSummaryPopup(orderData) {
        Swal.fire({
            title: 'Podsumowanie zamówienia',
            html: generateOrderHtml(orderData),
            showCancelButton: true,
            confirmButtonText: 'Potwierdź zamówienie',
            cancelButtonText: 'Wróć',
            didOpen: () => {
                $('#apply-discount').off('click').on('click', function() {
                    let enteredCode = $('#discount-code').val().trim();
                    if (!enteredCode) {
                        $('#discount-message').text('Proszę wpisać kod rabatowy.');
                        return;
                    }
                    $('#discount-message').text('');
                    // AJAX do walidacji kodu rabatowego
                    $.ajax({
                        url: wpAjax.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'apply_discount_code',
                            code: enteredCode
                        },
                        success: function(response) {
                            console.log('Odpowiedź z apply_discount_code:', response);
                            if (response.success) {
                                let discountPercentage = parseFloat(response.data.discount_percentage) ||
                                                         parseFloat(response.data.discount) || 0;
                                let baseTotal = cartItems.reduce((total, item) => total + (item.price + item.addonsTotalPrice), 0);
                                let discountValue = baseTotal * (discountPercentage / 100);
                                orderData.discountAmount = discountValue;
                                orderData.discountCode = enteredCode;
                                orderData.finalTotal = baseTotal + orderData.shippingCost - discountValue;
                                Swal.update({
                                    html: generateOrderHtml(orderData)
                                });
                            } else {
                                $('#discount-message').text(response.data.message || 'Kod rabatowy jest nieprawidłowy.');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Błąd AJAX przy walidacji kodu rabatowego:', status, error);
                            $('#discount-message').text('Błąd podczas weryfikacji kodu rabatowego.');
                        }
                    });
                });
            },
            preConfirm: () => {
                return orderData;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                let updatedOrderData = result.value;
                finalizeOrder(updatedOrderData);
            }
        });
    }

    // Funkcja finalizująca zamówienie – wysyłanie danych do backendu
    function finalizeOrder(orderData) {
        console.log("Finalizacja zamówienia:", orderData, cartItems);
        $.ajax({
            url: wpAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'save_order',
                customerName: orderData.customerName,
                customerPhone: orderData.phone,
                customerEmail: orderData.email,
                orderNotes: orderData.orderNotes,
                deliveryMethod: orderData.deliveryMethod,
                delivery_address: orderData.delivery_address,
                delivery_postcode: orderData.delivery_postcode,
                shippingCost: orderData.shippingCost,
                baseTotal: cartItems.reduce((total, item) => total + (item.price + item.addonsTotalPrice), 0),
                discountAmount: orderData.discountAmount || 0,
                discountCode: orderData.discountCode || '',
                finalTotal: orderData.finalTotal,
                cartItems: cartItems,
                paymentMethod: orderData.paymentMethod
            },
            success: function (response) {
                console.log('Odpowiedź z save_order:', response);
                if (response.success) {
                    Swal.fire({
                        title: 'Zamówienie złożone!',
                        text: 'Dziękujemy za zamówienie! Zamówienie zostało zapisane w systemie.',
                        icon: 'success'
                    });
                    cartItems = [];
                } else {
                    Swal.fire({
                        title: 'Błąd',
                        text: 'Nie udało się zapisać zamówienia.',
                        icon: 'error'
                    });
                }
            },
            error: function () {
                Swal.fire({
                    title: 'Błąd',
                    text: 'Nie udało się nawiązać połączenia z serwerem.',
                    icon: 'error'
                });
            }
        });
    }

    // Funkcja pobierająca dane dodatków (bez zmian)
    function updateAddonsContainer(selectedSize, addonIDs) {
        selectedSize = selectedSize.replace(/[^0-9]/g, "");
        addonIDs = [...new Set(addonIDs)];
        $.ajax({
            url: wpAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_addons_meta',
                addon_ids: addonIDs,
                pizza_size: selectedSize
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    let html = '';
                    let addonsData = response.data;
                    if (addonsData.length > 0) {
                        addonsData.forEach((addon) => {
                            let addonTitle = addon.title;
                            let addonPrice = 0;
                            if (typeof addon.addon_price !== "undefined") {
                                addonPrice = parseFloat(addon.addon_price) || 0;
                            } else {
                                if (selectedSize === "32" && typeof addon.addon_price_32 !== "undefined") {
                                    addonPrice = parseFloat(addon.addon_price_32) || 0;
                                } else if (selectedSize === "45" && typeof addon.addon_price_45 !== "undefined") {
                                    addonPrice = parseFloat(addon.addon_price_45) || 0;
                                } else if (selectedSize === "60" && typeof addon.addon_price_60 !== "undefined") {
                                    addonPrice = parseFloat(addon.addon_price_60) || 0;
                                }
                            }
                            html += `<label>
                                        <input type="checkbox" name="pizza-addons" value="${addonTitle}" data-price="${addonPrice}">
                                        ${addonTitle} ${addonPrice > 0 ? `( +${addonPrice.toFixed(2)} zł )` : ""}
                                     </label><br>`;
                        });
                    } else {
                        html = '<p>Brak dodatków</p>';
                    }
                    $('#addons-container').html(html);
                } else {
                    $('#addons-container').html('<p>Nie udało się pobrać dodatków.</p>');
                }
            },
            error: function() {
                $('#addons-container').html('<p>Błąd podczas pobierania dodatków.</p>');
            }
        });
    }

    // Funkcja wyświetlająca popup dla pizzy (bez zmian)
    function showPizzaPopup(productId, productName, productImage, sizePricesObj, addonIDs) {
        let optionsHtml = '';
        for (const sizeKey in sizePricesObj) {
            if (sizePricesObj.hasOwnProperty(sizeKey)) {
                let val = parseFloat(sizePricesObj[sizeKey]) || 0;
                optionsHtml += `<option value="${sizeKey}">${sizeKey} - ${val.toFixed(2)} zł</option>`;
            }
        }

        Swal.fire({
            title: 'Wybierz rozmiar pizzy i dodatki',
            html: `
                <select id="pizza-size" class="swal2-input" style="margin-bottom:10px;">
                    ${optionsHtml}
                </select>
                <div id="addons-container" style="text-align:left;">Ładowanie dodatków...</div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Dodaj do koszyka',
            cancelButtonText: 'Anuluj',
            didOpen: () => {
                if (addonIDs.length === 0) {
                    $('#addons-container').html('<p>Brak dodatków</p>');
                } else {
                    let selectedSize = $('#pizza-size').val();
                    updateAddonsContainer(selectedSize, addonIDs);
                    $('#pizza-size').on('change', function () {
                        let newSize = $(this).val();
                        updateAddonsContainer(newSize, addonIDs);
                    });
                }
            },
            preConfirm: () => {
                let selectedSize = $('#pizza-size').val() || 'standard';
                let addonNodes = document.querySelectorAll('input[name="pizza-addons"]:checked');
                let chosenAddons = Array.from(addonNodes).map(x => ({
                    title: x.value,
                    price: parseFloat(x.getAttribute('data-price')) || 0
                }));
                return { size: selectedSize, addons: chosenAddons };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                let chosenSize = result.value.size || 'standard';
                let chosenAddons = result.value.addons || [];
                let addonsTotalPrice = chosenAddons.reduce((total, addon) => total + addon.price, 0);
                let pizzaPrice = parseFloat(sizePricesObj[chosenSize]) || 0;

                cartItems.push({
                    productId: productId,
                    name: productName,
                    size: chosenSize,
                    addons: chosenAddons,
                    addonsTotalPrice: addonsTotalPrice,
                    price: pizzaPrice,
                    image: productImage
                });
                showCartPopup();
            }
        });
    }

    // =====================================================================================
    // SEKCJA – Wyświetlanie składników na karcie produktu (menu) przed kliknięciem "Zamów"
    // =====================================================================================
    $('.pizza-menu-item').each(function() {
        let $menuItem = $(this);
        let $addToCartBtn = $menuItem.find('.add-to-cart');
        // Sprawdzamy, czy produkt jest pizzą
        if ($addToCartBtn.attr('data-is-pizza') !== "1") {
            return; // pomijamy produkty niebędące pizzą
        }

        let rawAddons = $addToCartBtn.attr('data-addons') || "[]";
        let addonIDs;
        try {
            addonIDs = JSON.parse(rawAddons);
        } catch (e) {
            console.error("Błąd parsowania data-addons:", e);
            addonIDs = [];
        }

        if (addonIDs.length > 0) {
            let rawSizePrices = $addToCartBtn.attr('data-size-prices') || "{}";
            let sizePricesObj;
            try {
                sizePricesObj = JSON.parse(rawSizePrices);
            } catch (e) {
                console.error("Błąd parsowania data-size-prices:", e);
                sizePricesObj = {};
            }
            // Wybieramy domyślny rozmiar – pierwszy dostępny klucz
            let defaultSize = Object.keys(sizePricesObj)[0] || "";
            if (defaultSize) {
                $.ajax({
                    url: wpAjax.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'get_addons_meta',
                        addon_ids: addonIDs,
                        pizza_size: defaultSize
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log("Odpowiedź z get_addons_meta:", response);
                        if (response.success) {
                            let html = '';
                            let addonsData = response.data;
                            if (addonsData.length > 0) {
                                addonsData.forEach(function(addon) {
                                    let addonTitle = addon.title;
                                    let addonPrice = 0;
                                    if (typeof addon.addon_price !== 'undefined') {
                                        addonPrice = parseFloat(addon.addon_price) || 0;
                                    } else {
                                        if (defaultSize === "32" && typeof addon.addon_price_32 !== "undefined") {
                                            addonPrice = parseFloat(addon.addon_price_32) || 0;
                                        } else if (defaultSize === "45" && typeof addon.addon_price_45 !== "undefined") {
                                            addonPrice = parseFloat(addon.addon_price_45) || 0;
                                        } else if (defaultSize === "60" && typeof addon.addon_price_60 !== "undefined") {
                                            addonPrice = parseFloat(addon.addon_price_60) || 0;
                                        }
                                    }
                                    html += '<span>' + addonTitle + (addonPrice > 0 ? ' (+' + addonPrice.toFixed(2) + ' zł)' : '') + '</span>, ';
                                });
                                // Usuwamy ostatni przecinek i spację
                                html = html.slice(0, -2);
                            } else {
                                html = 'Brak dodatków';
                            }
                            $menuItem.find('.pizza-ingredients').html(html);

                            // ===============================
                            // NOWY KOD – SHOW/HIDE LIST
                            // ===============================
                            const $ingredientContainer = $menuItem.find('.pizza-ingredients');
                            const $spans = $ingredientContainer.find('span');
                            const maxVisible = 5;
                            if ($spans.length > maxVisible) {
                                $spans.slice(maxVisible).hide();
                                $ingredientContainer.append(
                                    '<button type="button" class="show-more-ingredients" style="display:block; margin-top:5px;">Pokaż więcej</button>'
                                );
                                $ingredientContainer.find('.show-more-ingredients').on('click', function() {
                                    if ($(this).text() === 'Pokaż więcej') {
                                        $spans.slice(maxVisible).show();
                                        $(this).text('Zwiń');
                                    } else {
                                        $spans.slice(maxVisible).hide();
                                        $(this).text('Pokaż więcej');
                                    }
                                });
                            }
                            // ===============================
                            // KONIEC NOWEGO KODU
                            // ===============================
                        } else {
                            console.warn("Response nie zawiera success=true:", response);
                            $menuItem.find('.pizza-ingredients').html('Błąd pobierania dodatków');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error("Błąd serwera w get_addons_meta:", textStatus, errorThrown);
                        $menuItem.find('.pizza-ingredients').html('Błąd serwera');
                    }
                });
            } else {
                console.warn("Brak zdefiniowanych rozmiarów w data-size-prices");
                $menuItem.find('.pizza-ingredients').html('Nie określono rozmiarów');
            }
        } else {
            $menuItem.find('.pizza-ingredients').html('Brak dodatków');
        }
    });
    // =====================================================================================

    // Obsługa przycisku "Dodaj do koszyka"
    $(document).on('click', '.add-to-cart', function (e) {
        e.preventDefault();

        let $productContainer = $(this).closest('.pizza-menu-item');

        let rawProductId  = $(this).attr('data-product-id') || "0";
        let rawIsPizza    = $(this).attr('data-is-pizza') || "0";
        let rawSizePrices = $(this).attr('data-size-prices') || "{}";
        let rawAddons     = $(this).attr('data-addons') || "[]";
        let productImage  = $productContainer.find('.thumbnail img').attr('src') || "";
        let productName   = $(this).attr('data-product-name') ||
                            $productContainer.find('h4').text().trim() ||
                            "Produkt";

        let basePrice = parseFloat($(this).attr('data-product-price'));
        if (isNaN(basePrice) || basePrice === 0) {
            let priceText = $productContainer.find('.price').first().text() || "0";
            priceText = priceText.replace(/[^0-9,\.\s]/g, '');
            priceText = priceText.replace(',', '.');
            basePrice = parseFloat(priceText) || 0;
        }

        console.log("Dodawany produkt:", productName, "| Cena:", basePrice);

        if (rawIsPizza === "1") {
            let sizePricesObj = {};
            try {
                sizePricesObj = JSON.parse(rawSizePrices);
            } catch (err) {
                console.error("Błąd JSON.parse(sizePrices):", err);
            }
            
            let addonIDs = [];
            try {
                addonIDs = JSON.parse(rawAddons);
                addonIDs = [...new Set(addonIDs)];
            } catch (err) {
                console.error("Błąd JSON.parse(addons):", err);
            }

            showPizzaPopup(rawProductId, productName, productImage, sizePricesObj, addonIDs);
        } else {
            addNonPizzaToCart(rawProductId, productName, productImage, basePrice);
        }
    });

    // Funkcja dodająca produkty niebędące pizzą do koszyka
    function addNonPizzaToCart(productId, productName, productImage, price) {
        console.log("Dodano produkt (nie-pizza):", productName, "| Cena:", price);
        cartItems.push({
            productId: productId,
            name: productName,
            size: null,
            addons: [],
            addonsTotalPrice: 0,
            price: price,
            image: productImage
        });

        Swal.fire({
            title: 'Dodano do koszyka',
            text: productName + ' został dodany do koszyka.',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(() => {
            showCartPopup();
        });
    }
});
