document.addEventListener("DOMContentLoaded", function () {
    const categoryButtons = document.querySelectorAll(".category-button");
    const menuContainer = document.querySelector(".menu-container");

    categoryButtons.forEach((button) => {
        button.addEventListener("click", function () {
            const category = this.dataset.category; // Pobierz kategorię z atrybutu data-category

            // Wyświetl komunikat podczas ładowania
            menuContainer.innerHTML = "<p>Loading...</p>";

            // Wysyłanie żądania AJAX
            fetch(`${pizzeriaAjax.ajax_url}?action=pizzeria_get_menu&category=${category}`)
                .then((response) => response.json())
                .then((data) => {
                    menuContainer.innerHTML = ""; // Wyczyść zawartość menu

                    if (data.success) {
                        data.data.forEach((item) => {
                            // Poniżej generujemy strukturę zgodną z oczekiwaniami koszyka:
                            // - .pizza-menu-item (klasa kontenera)
                            // - .price (pobierane przez cart.js, jeśli nie ma data-product-price)
                            // - .add-to-cart (przycisk, do którego cart.js się podpina)
                            menuContainer.innerHTML += `
                                <div class="pizza-menu-item">
                                    <div class="thumbnail">
                                        <img src="${item.thumbnail}" alt="${item.title}">
                                    </div>
                                    <h4>${item.title}</h4>
                                    <p class="price">${item.price} zł</p>
                                    <button class="add-to-cart"
                                        data-product-id="${item.id}"
                                        data-product-name="${item.title}"
                                        data-product-price="${item.price}"
                                        data-is-pizza="0"
                                        data-size-prices="{}"
                                        data-addons="[]"
                                    >Zamów</button>
                                </div>
                            `;
                        });
                    } else {
                        menuContainer.innerHTML = `<p>No dishes found in this category.</p>`;
                    }
                })
                .catch((error) => {
                    console.error("Error fetching menu:", error);
                    menuContainer.innerHTML = `<p>Error loading menu. Please try again.</p>`;
                });
        });
    });
});
