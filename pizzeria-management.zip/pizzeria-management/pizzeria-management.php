<?php
/*
Plugin Name: Pizzeria Management Plugin
Plugin URI: https://example.com
Description: Plugin for managing dishes, categories, and orders in a pizzeria.
Version: 1.1
Author: Your Name
Author URI: https://example.com
License: GPL2
*/

if (!defined('ABSPATH')) {
    exit; // Bezpośredni dostęp zabroniony
}

// 1. Wczytywanie modułów wtyczki
$plugin_includes = [
    'includes/cart.php',
    'includes/admin-menu.php',
    'includes/orders.php',
    'includes/dishes.php',
    'includes/addons.php',
    'includes/delivery-options.php',
    'includes/discount.php',
    'includes/settings.php',
    'includes/statistics.php',
    'includes/shortcodes.php',
    'includes/cart-handler.php',
];

foreach ($plugin_includes as $file) {
    $file_path = plugin_dir_path(__FILE__) . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    } else {
        error_log("Pizzeria Management Plugin: Failed to load $file");
    }
}

/**
 * Rejestrowanie stylu i skryptu dla Menu
 */
function pizzeria_enqueue_menu_assets() {
    $plugin_url = plugin_dir_url(__FILE__);

    // Styl menu (opcjonalny)
    wp_enqueue_style(
        'pizzeria-menu-styles',
        $plugin_url . 'assets/css/menu-style.css',
        [],
        '1.1.0',
        'all'
    );

    // Skrypt menu (opcjonalny)
    wp_enqueue_script(
        'pizzeria-menu-script',
        $plugin_url . 'assets/js/menu-script.js',
        ['jquery'],
        '1.1.0',
        true
    );

    // Przekazywanie ajax_url
    wp_localize_script('pizzeria-menu-script', 'pizzeriaAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
    ]);
}
add_action('wp_enqueue_scripts', 'pizzeria_enqueue_menu_assets');

/**
 * Rejestrowanie stylu i skryptu dla Koszyka
 */
function pizza_m_enqueue_cart_assets() {
    $plugin_url = plugin_dir_url(__FILE__);

    // Wczytanie SweetAlert2 z CDN
    wp_enqueue_script(
        'swal2',
        'https://cdn.jsdelivr.net/npm/sweetalert2@11',
        [],
        '11.0.0',
        true
    );

    // Styl koszyka
    wp_enqueue_style(
        'pizza-cart-styles',
        $plugin_url . 'assets/css/cart-style.css',
        [],
        '1.0.0',
        'all'
    );

    // Skrypt koszyka – upewnij się, że ładowany jest tylko jeden plik cart.js
    wp_enqueue_script(
        'pizza-cart-js',
        $plugin_url . 'assets/js/cart.js',
        ['jquery', 'swal2'],
        '1.0.0',
        true
    );

    // Lokalizacja parametrów do cart.js – używamy jednej zmiennej (np. wpAjax)
    wp_localize_script('pizza-cart-js', 'wpAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
    ]);
}
add_action('wp_enqueue_scripts', 'pizza_m_enqueue_cart_assets');

/**
 * AJAX Handler to Fetch Menu Items (przykład)
 */
function pizzeria_get_menu_items() {
    $category_slug = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';

    if (empty($category_slug)) {
        wp_send_json_error('No category provided.');
    }

    $args = [
        'post_type' => 'dish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
        'tax_query' => [
            [
                'taxonomy' => 'dish_category',
                'field' => 'slug',
                'terms' => $category_slug,
            ],
        ],
    ];

    $query = new WP_Query($args);
    if ($query->have_posts()) {
        $results = [];
        while ($query->have_posts()) {
            $query->the_post();
            $results[] = [
                'title'     => get_the_title(),
                'price'     => number_format((float) get_post_meta(get_the_ID(), '_dish_price', true), 2, ',', ''),
                'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail') ?: 'https://via.placeholder.com/150',
            ];
        }
        wp_send_json_success($results);
    } else {
        wp_send_json_error('No dishes found in this category.');
    }

    wp_reset_postdata();
}
add_action('wp_ajax_pizzeria_get_menu', 'pizzeria_get_menu_items');
add_action('wp_ajax_nopriv_pizzeria_get_menu', 'pizzeria_get_menu_items');

/**
 * Activation Hook
 */
function pizzeria_activate() {
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'pizzeria_activate');

/**
 * AJAX Handler for fetching delivery cost
 *
 * Zmieniono nazwę na get_delivery_cost, aby była zgodna z wywołaniem w JS.
 * Oczekuje się przesłania pola "postcode" (zgodnie z JS).
 */
add_action('wp_ajax_get_delivery_cost', 'get_delivery_cost');
add_action('wp_ajax_nopriv_get_delivery_cost', 'get_delivery_cost');

function get_delivery_cost() {
    global $wpdb;
    $postcode = isset($_POST['postcode']) ? sanitize_text_field($_POST['postcode']) : '';
    if (empty($postcode)) {
        wp_send_json_error(['message' => 'Kod pocztowy nie został podany.']);
    }
    $table_name = $wpdb->prefix . 'delivery_options';
    // Zakładamy, że w tabeli kolumna z kodem pocztowym to "postal_code"
    $delivery_price = $wpdb->get_var($wpdb->prepare(
        "SELECT delivery_price FROM $table_name WHERE postal_code = %s",
        $postcode
    ));
    if ($delivery_price !== null) {
        wp_send_json_success(['cost' => $delivery_price]);
    } else {
        wp_send_json_error(['message' => 'Nie znaleziono kosztu dostawy dla podanego kodu pocztowego.']);
    }
}

/**
 * AJAX Handler to Save Order
 *
 * Tutaj zmieniliśmy pizzeria_orders_items na pizzeria_order_items
 * oraz upewniamy się, że zapisujemy product_id zamiast dish_name.
 */
add_action('wp_ajax_save_order', 'save_order');
add_action('wp_ajax_nopriv_save_order', 'save_order');

function save_order() {
    global $wpdb;
    
    // Walidacja minimalnych pól
    if (empty($_POST['customerName']) || empty($_POST['deliveryMethod']) || empty($_POST['cartItems'])) {
        wp_send_json_error(['message' => 'Brak wymaganych danych zamówienia.']);
        return;
    }
    $customer_name     = sanitize_text_field($_POST['customerName']);
    $delivery_method   = sanitize_text_field($_POST['deliveryMethod']);
    $delivery_address  = sanitize_text_field($_POST['delivery_address'] ?? '');
    $delivery_postcode = sanitize_text_field($_POST['delivery_postcode'] ?? '');
    $shipping_cost     = isset($_POST['shippingCost']) ? floatval($_POST['shippingCost']) : 0.0;
    $base_total        = isset($_POST['baseTotal']) ? floatval($_POST['baseTotal']) : 0.0;
    $final_total       = isset($_POST['finalTotal']) ? floatval($_POST['finalTotal']) : 0.0;
    $cart_items        = $_POST['cartItems'];

    if (!is_array($cart_items) || empty($cart_items)) {
        wp_send_json_error(['message' => 'Koszyk jest pusty lub nieprawidłowy.']);
        return;
    }
    
    // Zapis do pizzeria_orders
    $wpdb->insert($wpdb->prefix . 'pizzeria_orders', [
        'customer_name'     => $customer_name,
        'delivery_method'   => $delivery_method,
        'delivery_address'  => $delivery_address,
        'delivery_postcode' => $delivery_postcode,
        'delivery_price'    => $shipping_cost,
        'base_total'        => $base_total,
        'final_total'       => $final_total,
        'created_at'        => current_time('mysql'),
    ]);
    $order_id = $wpdb->insert_id;
    if (!$order_id) {
        wp_send_json_error(['message' => 'Nie udało się zapisać zamówienia.']);
        return;
    }
    
    // Zapis każdej pozycji do pizzeria_order_items (ZAMIENIAMY pizzeria_orders_items -> pizzeria_order_items)
    foreach ($cart_items as $item) {
        $product_id         = intval($item['productId'] ?? 0);
        $size               = sanitize_text_field($item['size'] ?? '');
        $addons             = isset($item['addons']) ? wp_json_encode($item['addons']) : '[]';
        $addons_total_price = floatval($item['addonsTotalPrice'] ?? 0);
        $price              = floatval($item['price'] ?? 0);
        
        // Wstawiamy do pizzeria_order_items
        $wpdb->insert($wpdb->prefix . 'pizzeria_order_items', [
            'order_id'      => $order_id,
            'product_id'    => $product_id,
            'size'          => $size,
            'addons'        => $addons,
            'price'         => $price,
            'addons_price'  => $addons_total_price,
            'created_at'    => current_time('mysql'),
        ]);
    }
    wp_send_json_success(['message' => 'Zamówienie zostało zapisane.']);
}

/**
 * Opcjonalnie – jeśli chcesz mieć globalną zmienną ajaxurl w nagłówku:
 */
add_action('wp_head', function() {
    ?>
    <script type="text/javascript">
        var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
    </script>
    <?php
});
add_action('wp_ajax_get_addons_meta', 'pizzeria_get_addons_meta');
add_action('wp_ajax_nopriv_get_addons_meta', 'pizzeria_get_addons_meta');

function pizzeria_get_addons_meta() {
    error_log('[pizzeria_get_addons_meta] Start handler.');

    if ( empty($_POST['addon_ids']) ) {
        error_log('[pizzeria_get_addons_meta] No addon_ids provided.');
        wp_send_json_error(array('message' => 'No addon_ids provided.'));
        wp_die();
    }

    $addon_ids = $_POST['addon_ids'];
    if ( ! is_array($addon_ids) ) {
        $addon_ids = json_decode(stripslashes($addon_ids), true);
        if ( ! is_array($addon_ids) ) {
            // Fallback: traktujemy dane jako ciąg znaków rozdzielony przecinkami
            $addon_ids = explode(',', $_POST['addon_ids']);
        }
    }
    // Usuń puste elementy oraz duplikaty
    $addon_ids = array_filter($addon_ids, function($value) {
        if (is_array($value)) {
            return isset($value['title']) && strlen(trim($value['title'])) > 0;
        }
        return strlen(trim($value)) > 0;
    });
    $addon_ids = array_unique($addon_ids, SORT_REGULAR);

    // Pobieramy parametr pizza_size (np. "32", "45" lub "60")
    $pizza_size = isset($_POST['pizza_size']) ? sanitize_text_field($_POST['pizza_size']) : '';

    $result = array();
    foreach ($addon_ids as $addon) {
        $addon_post = false;
        // Jeśli wartość jest numeryczna, traktujemy ją jako ID
        if (is_numeric($addon)) {
            $addon_id = intval($addon);
            $addon_post = get_post($addon_id);
        }
        // Jeśli wartość jest tablicą – wyciągamy z niej tytuł
        else if (is_array($addon)) {
            $addon_value = isset($addon['title']) ? sanitize_text_field($addon['title']) : '';
            if (empty($addon_value)) {
                error_log('[pizzeria_get_addons_meta] Empty title in addon array: ' . print_r($addon, true));
                continue;
            }
            $addon_post = get_page_by_title($addon_value, OBJECT, 'addon');
            if ( ! $addon_post ) {
                // Jeśli nie znaleziono po tytule, próbujemy wyszukać po slug’u
                $args = array(
                    'post_type'      => 'addon',
                    'name'           => $addon_value,
                    'post_status'    => 'publish',
                    'posts_per_page' => 1,
                );
                $query = new WP_Query($args);
                if ($query->have_posts()) {
                    $addon_post = $query->posts[0];
                }
                wp_reset_postdata();
            }
            $addon_id = $addon_post ? $addon_post->ID : 0;
        }
        // Inny przypadek – traktujemy wartość jako tekst (tytuł)
        else {
            $addon_value = sanitize_text_field($addon);
            if (empty($addon_value)) {
                continue;
            }
            $addon_post = get_page_by_title($addon_value, OBJECT, 'addon');
            if (!$addon_post) {
                $args = array(
                    'post_type'      => 'addon',
                    'name'           => $addon_value,
                    'post_status'    => 'publish',
                    'posts_per_page' => 1,
                );
                $query = new WP_Query($args);
                if ($query->have_posts()) {
                    $addon_post = $query->posts[0];
                }
                wp_reset_postdata();
            }
            $addon_id = $addon_post ? $addon_post->ID : 0;
        }

        if ( ! $addon_post ) {
            error_log('[pizzeria_get_addons_meta] No post found for addon: ' . print_r($addon, true));
            continue;
        }

        // Upewniamy się, że post należy do typu "addon"
        if ($addon_post->post_type !== 'addon') {
            error_log('[pizzeria_get_addons_meta] Skipping post ' . $addon_post->ID . ' - not of type addon.');
            continue;
        }

        if ( in_array($pizza_size, array('32', '45', '60')) ) {
            // Pobieramy cenę dla wybranego rozmiaru pizzy
            $price = get_post_meta($addon_post->ID, '_addon_price_' . $pizza_size, true);
            $result[] = array(
                'id'          => $addon_post->ID,
                'title'       => $addon_post->post_title,
                'addon_price' => $price ? $price : '0.00'
            );
        } else {
            // Jeśli nie przekazano rozmiaru – zwracamy wszystkie ceny
            $price_32 = get_post_meta($addon_post->ID, '_addon_price_32', true);
            $price_45 = get_post_meta($addon_post->ID, '_addon_price_45', true);
            $price_60 = get_post_meta($addon_post->ID, '_addon_price_60', true);
            $result[] = array(
                'id'              => $addon_post->ID,
                'title'           => $addon_post->post_title,
                'addon_price_32'  => $price_32 ? $price_32 : '0.00',
                'addon_price_45'  => $price_45 ? $price_45 : '0.00',
                'addon_price_60'  => $price_60 ? $price_60 : '0.00'
            );
        }
        error_log('[pizzeria_get_addons_meta] Processed addon: ' . $addon_post->ID . ' - ' . print_r(end($result), true));
    }

    error_log('[pizzeria_get_addons_meta] Final result: ' . print_r($result, true));
    
    wp_send_json_success($result);
    wp_die();
}
function custom_wp_mail_from($email) {
    // Używamy home_url(), aby pobrać aktualny adres witryny
    $site_url = home_url();
    // Wyłuskujemy domenę z URL
    $domain = wp_parse_url($site_url, PHP_URL_HOST);
    // Jeśli z jakiegoś powodu nie uda się pobrać domeny, ustawiamy domyślną
    if (!$domain) {
        $domain = 'example.com';
    }
    return 'zamowienia@' . $domain;
}
add_filter('wp_mail_from', 'custom_wp_mail_from');

function custom_wp_mail_from_name($name) {
    return 'Zamówienia';
}
add_filter('wp_mail_from_name', 'custom_wp_mail_from_name');
